package form;

import bean.LocalPcBean;
import bean.MemberBean;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SelectPc extends JFrame{

	JComboBox cmb;
	JTextField tf;
	JTextArea ta;
	JPanel p;
	JScrollBar sc;
	private static  MemberBean mbean;
	private static LocalPcBean pcbean;


	public SelectPc() {
		setSize(600, 550);
		setTitle("피시방 선택");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		cmb = new JComboBox();
		cmb.setBounds(34, 10, 179, 23);
		getContentPane().add(cmb);

		tf = new JTextField();
		tf.setBounds(275, 12, 165, 21);
		getContentPane().add(tf);
		tf.setColumns(10);

		p = new JPanel();
		p.setBounds(34, 57, 412, 427);
		getContentPane().add(p);
		p.setLayout(null);

		ta = new JTextArea();
		ta.setBounds(12, 10, 371, 396);
		p.add(ta);

		sc = new JScrollBar();
		sc.setBounds(383, 10, 17, 396);
		p.add(sc);

		setResizable(false);
		this.setVisible(true);
		validate();
	}
	public static void setMemberBean(MemberBean bean) {
		SelectPc.mbean = bean;
	}
	public static void setLocalPcBean(LocalPcBean bean) {
		SelectPc.pcbean = bean;
	}
	public static void main(String[] args) {
		new SelectPc();
	}
}
