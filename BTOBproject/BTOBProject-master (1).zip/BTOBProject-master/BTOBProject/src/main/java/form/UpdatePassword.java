package form;

import DB.MemberMgr;
import bean.MemberBean;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class UpdatePassword extends JFrame
        implements ActionListener{

    LoginHome lf;
    JLabel lbl1, lbl2;
    JButton btn1, btn2;
    JPasswordField tf1, tf2;
    DialogBox err1;
    MemberMgr mgr;
    private static MemberBean bean;

    public UpdatePassword() {
        setTitle("비밀번호 변경");
        setBounds(100, 100, 404, 314);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lbl1 = new JLabel("비밀번호 입력");
        lbl1.setBounds(12, 52, 80, 15);
        getContentPane().add(lbl1);

        lbl2 = new JLabel("비밀번호 확인");
        lbl2.setBounds(12, 100, 97, 19);
        getContentPane().add(lbl2);

        tf1 = new JPasswordField();
        tf1.setBounds(147, 47, 196, 24);
        getContentPane().add(tf1);

        tf2 = new JPasswordField();
        tf2.setBounds(147, 95, 196, 24);
        getContentPane().add(tf2);

        btn1 = new JButton("확인");
        btn1.setBounds(61, 228, 97, 23);
        getContentPane().add(btn1);

        btn2 = new JButton("취소");
        btn2.setBounds(187, 228, 97, 23);
        getContentPane().add(btn2);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
        setResizable(false);
        setVisible(true);
        validate();
    }

    public static void setBean(MemberBean bean) {
        UpdatePassword.bean = bean;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == btn1) {
            if(tf1.getText().equals(tf2.getText())) {
                mgr = new MemberMgr();
                bean.setUserPassword(tf1.getText());
                System.out.println(bean.toString());
                mgr.updatePassword(bean);

                lf = new LoginHome();
                lf.setLocation(getX(),getY());
                this.dispose();
            }else {
                //	err1 = new DialogBox(this, "올바르지 않은 정보입니다.","알림");
            }
        } else if (obj == btn2) {
            lf = new LoginHome();
            lf.setLocation(getX(),getY());
            dispose();
        }
    }

}
