package form;

import DB.MenuMgr;
import bean.LocalBean;
import bean.LocalPcBean;
import bean.MemberBean;
import bean.MenuPocketBean;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class PaymentList extends  JFrame{
    private JTable table;
    JButton backbtn;
    JLabel userlabel, idlabel, totallabel;
    JTextField total;
    Choice ch;
    MenuMgr menuMgr;
    Vector<MenuPocketBean> pocketBeans;
    int totalprice = 0;
    private static MemberBean mbean;

    public PaymentList() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );

        setBounds(100, 100, 720, 695);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(null);

        System.out.println(mbean.getUserId());
        pocketBeans = new Vector<>();
        menuMgr = new MenuMgr();
        pocketBeans = menuMgr.getUserPaymentDateList(mbean.getUserId());
        String pockettime[] = new String[pocketBeans.size()];
        ch = new Choice();
        ch.setBackground(Color.GRAY);
        ch.setBounds(388, 50, 173, 21);
        ch.add("전체조회");
        for (int i = 0; i < pocketBeans.size(); i++) {   //
            MenuPocketBean pocketBean = pocketBeans.get(i);
            String strNowDate = String.valueOf(pocketBean.getPocketTime());
            pockettime[i] =strNowDate;
            ch.add(pockettime[i]);
        }
        add(ch);

        DefaultTableModel model = new DefaultTableModel(new Object[]{"ID","피시방 이름", "메뉴명", "수량", "가격","결제시간"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> String.class;
                    case 1 -> String.class;
                    case 2 -> String.class;
                    case 3 -> Integer.class;
                    case 4 -> Integer.class;
                    case 5 -> String.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable();
        table.setModel(model);

        TableCellRenderer dateRenderer = new DefaultTableCellRenderer() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if (value instanceof Timestamp) {
                    value = sdf.format(value); // Timestamp를 문자열로 변환
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        };

        // Timestamp 열에 TableCellRenderer 적용
        table.getColumnModel().getColumn(5).setCellRenderer(dateRenderer);

        pocketBeans = menuMgr.getUserPaymentAllList(mbean.getUserId());

        //처음 로드 데이터 삽입
        for (int i = 0; i <= pocketBeans.size()-1; i++) {
            MenuPocketBean pocketBean = pocketBeans.get(i);
            model.addRow(new Object[]{mbean.getUserId(),pocketBean.getlocalPcBean().getLocal_pcName(),
                    pocketBean.getMenuName(), pocketBean.getMenuCount(),pocketBean.getMenuCount()*pocketBean.getMenuPrice(), pocketBean.getPocketTime()});
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(5, 136, 695, 451);

        table.getTableHeader().setReorderingAllowed(false);         // 컬럼들 이동 불가
        table.getTableHeader().setResizingAllowed(false);           // 컬럼 크기 조절 불가

        table.setDefaultRenderer(String.class, centerRenderer);
        table.setDefaultRenderer(Integer.class, centerRenderer);
        add(scrollPane);

        backbtn= new JButton("닫기");
        backbtn.setBounds(153, 625, 434, 29);
        add(backbtn, BorderLayout.SOUTH);

        userlabel = new JLabel("유저 아이디 : ");
        userlabel.setBounds(182, 53, 80, 15);
        add(userlabel, BorderLayout.WEST);

        idlabel = new JLabel(mbean.getUserId());
        idlabel.setBounds(261, 53, 100, 15);
        add(idlabel);

        total = new JTextField();
        total.setBounds(308, 596, 116, 21);
        add(total);
        total.setColumns(10);
        total.setEnabled(false);
        total.setVisible(false);

        totallabel = new JLabel("총액 : ");
        totallabel.setBounds(223, 602, 57, 15);
        add(totallabel);
        totallabel.setVisible(false);

        backbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        ch.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                model.setNumRows(0);
                String str = ch.getSelectedItem();
                totalprice = 0;
                if (str == "전체조회") {
                    pocketBeans = menuMgr.getUserPaymentAllList(mbean.getUserId());
                    for (int i = 0; i <= pocketBeans.size()-1; i++) {
                        MenuPocketBean pocketBean = pocketBeans.get(i);
                        model.addRow(new Object[]{mbean.getUserId(),pocketBean.getlocalPcBean().getLocal_pcName(),
                                pocketBean.getMenuName(), pocketBean.getMenuCount(),pocketBean.getMenuCount()*pocketBean.getMenuPrice(), pocketBean.getPocketTime()});
                    }
                    total.setVisible(false);
                    totallabel.setVisible(false);
                }else {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String selectedTimestampStr = ch.getSelectedItem();
                    Timestamp selectedTimestamp = null;
                    try {
                        selectedTimestamp = Timestamp.valueOf(selectedTimestampStr);
                    } catch (IllegalArgumentException e2) {
                        // Timestamp 파싱 오류 처리 (예외 처리 코드 추가)
                        e2.printStackTrace();
                    }
                    pocketBeans = menuMgr.getUserPaymentList(mbean.getUserId(), selectedTimestamp);
                    for (int i = 0; i <= pocketBeans.size()-1; i++) {
                        MenuPocketBean pocketBean = pocketBeans.get(i);
                        model.addRow(new Object[]{mbean.getUserId(),pocketBean.getlocalPcBean().getLocal_pcName(),
                                pocketBean.getMenuName(), pocketBean.getMenuCount(),pocketBean.getMenuCount()*pocketBean.getMenuPrice(), pocketBean.getPocketTime()});
                        totalprice += pocketBean.getMenuCount()*pocketBean.getMenuPrice();
                    }
                    total.setVisible(true);
                    totallabel.setVisible(true);
                    total.setText(String.valueOf(totalprice));
                }
            }
        });

        table.getColumnModel().getColumn(1).setMinWidth(100);
        table.getColumnModel().getColumn(5).setMinWidth(150);

        setVisible(true);
        setResizable(false);
        validate();
    }

    public static void setBean(MemberBean bean) {
        PaymentList.mbean = bean;
    }
}