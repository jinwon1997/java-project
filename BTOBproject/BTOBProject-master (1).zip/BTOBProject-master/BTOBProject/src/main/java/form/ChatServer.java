package form;

import DB.ChatMgr;
import bean.ChatBean;
import com.mysql.cj.xdevapi.Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class ChatServer {

    private static int port;
    Vector<Client> vc;
    ServerSocket server;
    ChatMgr mgr;
    public static int[] user_num = new int[11];

    public ChatServer(int port) {
        try {
            vc = new Vector<Client>();
            server = new ServerSocket(port);
            mgr = new ChatMgr();
        } catch (Exception e) {
            System.err.println("Error in Server");
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("****************************************");
        System.out.println("*Welcome Chat Server 3.0...");
        System.out.println("*클라이언트 접속을 기다리고 있습니다.");
        System.out.println("****************************************");
        try {
            while (true) {
                Socket sock = server.accept();
                Client ct = new Client(sock);
                ct.start();
                vc.addElement(ct);
            }
        } catch (Exception e) {
            System.err.println("Error in Socket");
            e.printStackTrace();
        }
    }

    public void sendAllMessage(String msg) {
        for (int i = 0; i < vc.size(); i++) {
            Client ct = vc.elementAt(i);
            ct.sendMessage(msg);
        }
    }

    public void removeClient(Client ct) {
        vc.remove(ct);
    }

    // 접속된 모든 id 리스트 리턴 ex) aaa;bbb;ccc;ddd;홍길동;
    public String getIdList() {
        String ids = "";
        for (int i = 0; i < vc.size(); i++) {
            Client ct = vc.get(i);
            ids += ct.id + ";";
        }
        return ids;
    }

    // 매개변수 id값으로 Client3를 검색
    public Client findClient(String id) {
        Client ct = null;
        for (int i = 0; i < vc.size(); i++) {
            ct = vc.get(i);
            if (ct.id.equals(id)) {// 매개변수 id와 Client의 id와 같다면...
                break;
            }
        } // --for
        return ct;
    }// --findClient

    class Client extends Thread {

        Socket sock;
        BufferedReader in;
        PrintWriter out;
        String id = "익명";

        public Client(Socket sock) {
            try {
                this.sock = sock;
                in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                out = new PrintWriter((sock.getOutputStream()), true);
                System.out.println(sock + " 접속됨...");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                while (true) {
                    String line = in.readLine();
                    if (line == null)
                        break;
                    else
                        routine(line);
                }
            } catch (Exception e) {
                removeClient(this);
                System.err.println(sock + "[" + id + "] 끊어짐...");
            }
        }

        public void routine(String line) {
            System.out.println("line:" + line);
            int idx = line.indexOf(ChatProtocol.MODE);
            String cmd = line.substring(0, idx);
            String data = line.substring(idx + 1);
            //ID:aaa;1234
            if (cmd.equals(ChatProtocol.ID)) {
                idx = data.indexOf(';');
                cmd = data.substring(0, idx);
                data = data.substring(idx + 1);
                if(mgr.loginChk(cmd, data)) {
                    //로그인 성공
                    Client ct = findClient(cmd);
                    if(ct!=null&&ct.id.equals(cmd)) {
                        //이중접속
                        sendMessage(ChatProtocol.ID + ChatProtocol.MODE+"C");
                    }else {
                        id = cmd;
                        sendMessage(ChatProtocol.ID + ChatProtocol.MODE+"T");
                        sendAllMessage(ChatProtocol.CHATLIST + ChatProtocol.MODE+getIdList());
                        sendAllMessage(ChatProtocol.CHATALL + ChatProtocol.MODE+"["+id+"]님이 입장하였습니다");
                    }
                } else {//로그인 실패
                    sendMessage(ChatProtocol.ID + ChatProtocol.MODE+"F");
                }
            } else if (cmd.equals(ChatProtocol.CHAT)) {// CHAT:bbb;밥먹자
                idx = data.indexOf(';');
                cmd/* bbb */ = data.substring(idx);
                data/* 밥먹자 */ = data.substring(idx + 1);
                // id : bbb를 가진 클라이언트를 찾아야 한다.
                Client ct = findClient(cmd);
                if (ct != null) {// 상대방과 자신에게 보냄
                    ct.sendMessage(ChatProtocol.CHAT + ChatProtocol.MODE + "[" + id + "(S)]" + data); // bbb에게 날라가는것(상대방) , data = // 귓속말
                    sendMessage(ChatProtocol.CHAT + ChatProtocol.MODE + "[" + id + "(S)]" + data); // 자신(aaa)에게 날라옴(sendMessage)
                } else {// 자신에게 보내는것 (aaa)
                    sendMessage(ChatProtocol.CHAT + ChatProtocol.MODE + "[" + cmd + "]님이 접속자가 아닙니다.");
                }
            } else if (cmd.equals(ChatProtocol.CHATALL)) {
                sendAllMessage(ChatProtocol.CHATALL + ChatProtocol.MODE + "[" + id + "]" + data);
            } else if (cmd.equals(ChatProtocol.MESSAGE)) {
                idx = data.indexOf(';');
                cmd = data.substring(0, idx);
                data = data.substring(idx + 1);
                Client ct = findClient(cmd);
                ChatBean bean = new ChatBean();
                bean.setFid(id);//aaa
                bean.setTid(cmd);//bbb
                bean.setMsg(data);//오늘 뭐해?
                mgr.insertMsg(bean);//DB저장
                ct.sendMessage(ChatProtocol.MESSAGE+ChatProtocol.MODE+id+";"+data);
            }else if (cmd.equals(ChatProtocol.MSGLIST)) {
                //MSGLIST:aaa,bbb,밥먹자;bbb,ccc,하이;...
                Vector<ChatBean> vlist = mgr.getMsgList(id);
                String str = "";
                for (ChatBean bean : vlist) {
                    str+=bean.getFid()+",";
                    str+=bean.getTid()+",";
                    str+=bean.getMsg()+";";
                }
                sendMessage(ChatProtocol.MSGLIST+ChatProtocol.MODE+str);
            } else if (/*data.equals("방을 나갔습니다.")*/cmd.equals(ChatProtocol.CHATOUT)) {
                System.out.println("당근을 흔들어주세요.");
                handleExit(id);
            }
        }

        // ChatServer 클래스 내에 퇴장 정보 처리 메서드 추가
        public void handleExit(String id) {
            Client ct = findClient(id);
            if (ct != null) {
                sendAllMessage(ChatProtocol.CHATALL + ChatProtocol.MODE + "[" + id + "]님이 퇴장하였습니다.");
                removeClient(ct);
                sendAllMessage(ChatProtocol.CHATLIST + ChatProtocol.MODE+getIdList());
            }
        }

        public void sendMessage(String msg) {
            out.println(msg);
        }
    }
    public void startServer() {
        System.out.println("****************************************");
        System.out.println("*Welcome Chat Server 3.0...");
        System.out.println("*클라이언트 접속을 기다리고 있습니다.");
        System.out.println("****************************************");
        try {
            while (true) {
                Socket sock = server.accept();
                Client ct = new Client(sock);
                ct.start();
                vc.addElement(ct);
            }
        } catch (Exception e) {
            System.err.println("Error in Socket");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        int[] ports = {8101, 8102, 8103,8104};
        List<Thread> threads = new ArrayList<>();

        for (int port : ports) {
            ChatServer chatServer = new ChatServer(port);
            Thread thread = new Thread(() -> chatServer.startServer());
            threads.add(thread);
            thread.start();
        }

        // 모든 스레드가 종료될 때까지 기다립니다.
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}