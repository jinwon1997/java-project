package form;


import DB.AdminMgr;
import DB.MemberMgr;
import admin.Admin;
import admin.pc.PcManagementSystem;
import bean.GameBean;
import bean.MemberBean;
import security.Encryption;

import java.awt.Graphics;
import java.awt.TextField;
import java.awt.event.*;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import static security.Encryption.SHA256;


public class LoginHome extends JFrame implements ActionListener, KeyListener {

    JLabel la1, la2;
    static TextField tf1;
    TextField tf2;
    JButton btn1, btn2, btn3, btn4;
    ImageIcon fristimage;
    CreateMember cm;
    Vector<MemberBean> vlist;
    DialogBox err1;
    Findid fid;
    Findpassword fpd;
    LocalPc localPc;
    MemberMgr mgr;
    Encryption enc;
    MemberBean bean = new MemberBean();
    AdminMgr adminMgr;
    Vector<GameBean> gameBeans;

    public LoginHome() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("BTOB");
        fristimage = new ImageIcon("C:\\myeongseung\\Pro\\BTOBProject\\src\\main\\java\\images\\pcbackground.png");

        JPanel panel = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(fristimage.getImage(), 0, 0, null);
                setOpaque(false);
            }
        };

        panel.setLayout(null);
        panel.setBounds(0, 0, 1200, 800);
        add(panel);

        panel.add(la1 = new JLabel("ID"));  // layout을 null로 줘서 크기와 위치를 지정해야 보임
        panel.add(tf1 = new TextField("",10));
        panel.add(la2 = new JLabel("비밀번호"));
        panel.add(tf2 = new TextField("",20));
        tf2.setEchoChar('●');

        la1.setBounds(300, 700, 20, 30);
        tf1.setBounds(330, 700, 90, 30);
        la2.setBounds(430, 700, 60, 30);
        tf2.setBounds(490, 700, 90, 30);

        panel.add(btn1 = new JButton("로그인"));
        panel.add(btn2 = new JButton("회원가입"));
        panel.add(btn3 = new JButton("아이디 찾기"));
        panel.add(btn4 = new JButton("비밀번호 찾기"));

        btn1.setBounds(630, 700, 100, 30);
        btn2.setBounds(740, 700, 100, 30);
        btn3.setBounds(850, 700, 100, 30);
        btn4.setBounds(960, 700, 130, 30);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        setSize(1200, 840);
        setVisible(true);
        setResizable(false);
        validate();
        tf1.addKeyListener(this);
        tf2.addKeyListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        mgr = new MemberMgr();
        enc = new Encryption();

        if(obj==btn1/*로그인하기*/) {
            String id = tf1.getText();
            String pw = null;
            try {
                pw = SHA256(tf2.getText());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
            if (id.equals((bean = mgr.getIdPw(id,pw)).getUserId()) &&
                    pw.equals(mgr.getIdPw(id,pw).getUserPassword())) {
                if(mgr.getIdPw(id,pw).getUserAuthority() == 1){ //관리자 로그인
                    Admin admin = new Admin();
                    dispose();
                }else{
                    bean = mgr.getUserInfo(bean);
                    localPc.setBean(bean);
                    localPc = new LocalPc();
                    setVisible(false);
                }
            }else {
                DialogBox err1 = new DialogBox(this, "아이디 혹은 비밀번호가 올바르지 않습니다.","알림");
            }

        }else if(obj==btn2/*회원가입*/) {
            if (cm==null) {
                cm = new CreateMember();
                cm.setLocation(getX(),getY());
                dispose();
            }
        }else if(obj==btn3/*아이디 찾기*/) {
            if (fid==null) {
                fid = new Findid();
                fid.setLocation(getX(),getY());
                dispose();
            }
        }else if(obj==btn4/*비밀번호 찾기*/) {
            if (fpd==null) {
                fpd = new Findpassword();
                fpd.setLocation(getX(),getY());
                dispose();
            }
        }
    }

    public static void main(String[] args) {
        new LoginHome();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            btn1.doClick();  // 로그인 버튼 클릭 시뮬레이트
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
