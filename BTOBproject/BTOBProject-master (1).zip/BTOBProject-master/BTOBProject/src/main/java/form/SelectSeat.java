package form;

import DB.LocalMgr;
import DB.MemberMgr;
import DB.PcSeatMgr;
import bean.LocalPcBean;
import bean.MemberBean;
import bean.PcSeatBean;

import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SelectSeat extends JFrame implements ActionListener{

    JButton btn1;
    private static MemberBean mbean;
    private static LocalPcBean pcbean;
    private static PcSeatBean pcseatbean;
    MenuBar bar;
    Menu file;
    MyPage page;
    MenuPan menu;
    Seat_Box seat;
    Game game;


    public SelectSeat() {
        //System.out.println(mbean.getUserId());
        setTitle(pcbean.getLocal_pcNum() + " : "+ pcbean.getLocal_pcName() + " : " + mbean.getUserId());
        setBounds(100, 100, 1000, 550);
        setLayout(null);
        pcseatbean = new PcSeatBean();

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 0, 0));
        panel.setBounds(0, 0, 1000, 500);
        getContentPane().add(panel);
        panel.setLayout(null);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(0, 0, 0));
        panel_1.setForeground(new Color(255, 255, 255));
        panel_1.setBounds(0, 0, 905, 56);
        panel.add(panel_1);
        panel_1.setLayout(null);

        JLabel lblNewLabel_1 = new JLabel("\uC88C\uC11D \uC120\uD0DD\uCC3D");
        lblNewLabel_1.setText(pcbean.getLocal_pcName());
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setBounds(416, 31, 300, 15);
        panel_1.add(lblNewLabel_1);

        btn1 = new JButton("1");
        btn1.setForeground(new Color(255, 255, 255));
        btn1.setBackground(new Color(128, 0, 255));
        btn1.setBounds(86, 92, 57, 23);
        panel.add(btn1);
        btn1.addActionListener(this);


        JButton btn2 = new JButton("2");
        btn2.setForeground(new Color(255, 255, 255));
        btn2.setBackground(new Color(128, 0, 255));
        btn2.setBounds(182, 92, 57, 23);
        panel.add(btn2);
        btn2.addActionListener(this);

        JButton btn3 = new JButton("3");
        btn3.setForeground(new Color(255, 255, 255));
        btn3.setBackground(new Color(128, 0, 255));
        btn3.setBounds(86, 125, 57, 23);
        panel.add(btn3);
        btn3.addActionListener(this);

        JButton btn4 = new JButton("4");
        btn4.setForeground(new Color(255, 255, 255));
        btn4.setBackground(new Color(128, 0, 255));
        btn4.setBounds(182, 125, 57, 23);
        panel.add(btn4);
        btn4.addActionListener(this);

        JButton btn5 = new JButton("5");
        btn5.setForeground(new Color(255, 255, 255));
        btn5.setBackground(new Color(128, 0, 255));
        btn5.setBounds(86, 158, 57, 23);
        panel.add(btn5);
        btn5.addActionListener(this);

        JButton btn6 = new JButton("6");
        btn6.setForeground(new Color(255, 255, 255));
        btn6.setBackground(new Color(128, 0, 255));
        btn6.setBounds(182, 158, 57, 23);
        panel.add(btn6);
        btn6.addActionListener(this);

        JButton btn7 = new JButton("7");
        btn7.setForeground(new Color(255, 255, 255));
        btn7.setBackground(new Color(128, 0, 255));
        btn7.setBounds(86, 193, 57, 23);
        panel.add(btn7);
        btn7.addActionListener(this);

        JButton btn8 = new JButton("8");
        btn8.setForeground(new Color(255, 255, 255));
        btn8.setBackground(new Color(128, 0, 255));
        btn8.setBounds(182, 193, 57, 23);
        panel.add(btn8);
        btn8.addActionListener(this);

        JButton btn9 = new JButton("9");
        btn9.setForeground(new Color(255, 255, 255));
        btn9.setBackground(new Color(128, 0, 255));
        btn9.setBounds(86, 226, 57, 23);
        panel.add(btn9);
        btn9.addActionListener(this);

        JButton btn10 = new JButton("10");
        btn10.setForeground(new Color(255, 255, 255));
        btn10.setBackground(new Color(128, 0, 255));
        btn10.setBounds(182, 226, 57, 23);
        panel.add(btn10);
        btn10.addActionListener(this);

        JButton btn11 = new JButton("11");
        btn11.setForeground(new Color(255, 255, 255));
        btn11.setBackground(new Color(128, 0, 255));
        btn11.setBounds(86, 259, 57, 23);
        panel.add(btn11);
        btn11.addActionListener(this);


        JButton btn12 = new JButton("12");
        btn12.setForeground(new Color(255, 255, 255));
        btn12.setBackground(new Color(128, 0, 255));
        btn12.setBounds(182, 259, 57, 23);
        panel.add(btn12);
        btn12.addActionListener(this);

        JButton btn13 = new JButton("13");
        btn13.setForeground(new Color(255, 255, 255));
        btn13.setBackground(new Color(128, 0, 255));
        btn13.setBounds(86, 292, 57, 23);
        panel.add(btn13);
        btn13.addActionListener(this);

        JButton btn14 = new JButton("14");
        btn14.setForeground(new Color(255, 255, 255));
        btn14.setBackground(new Color(128, 0, 255));
        btn14.setBounds(182, 292, 57, 23);
        panel.add(btn14);
        btn14.addActionListener(this);

        JButton btn15 = new JButton("15");
        btn15.setForeground(new Color(255, 255, 255));
        btn15.setBackground(new Color(128, 0, 255));
        btn15.setBounds(86, 325, 57, 23);
        panel.add(btn15);
        btn15.addActionListener(this);

        JButton btn16 = new JButton("16");
        btn16.setForeground(new Color(255, 255, 255));
        btn16.setBackground(new Color(128, 0, 255));
        btn16.setBounds(182, 325, 57, 23);
        panel.add(btn16);
        btn16.addActionListener(this);

        JButton btnback = new JButton("\uB4A4\uB85C\uAC00\uAE30");
        btnback.setBounds(0, 467, 89, 23);
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        panel.add(btnback);

        JButton btn55 = new JButton("55");
        btn55.setForeground(new Color(255, 255, 255));
        btn55.setBackground(new Color(128, 0, 255));
        btn55.setBounds(86, 371, 57, 23);
        panel.add(btn55);
        btn55.addActionListener(this);

        JButton btn56 = new JButton("56");
        btn56.setForeground(new Color(255, 255, 255));
        btn56.setBackground(new Color(128, 0, 255));
        btn56.setBounds(182, 371, 57, 23);
        panel.add(btn56);
        btn56.addActionListener(this);

        JButton btn57 = new JButton("57");
        btn57.setForeground(new Color(255, 255, 255));
        btn57.setBackground(new Color(128, 0, 255));
        btn57.setBounds(86, 394, 57, 23);
        panel.add(btn57);
        btn57.addActionListener(this);

        JButton btn58 = new JButton("58");
        btn58.setForeground(new Color(255, 255, 255));
        btn58.setBackground(new Color(128, 0, 255));
        btn58.setBounds(182, 394, 57, 23);
        panel.add(btn58);
        btn58.addActionListener(this);

        JButton btn59 = new JButton("59");
        btn59.setForeground(new Color(255, 255, 255));
        btn59.setBackground(new Color(128, 0, 255));
        btn59.setBounds(277, 371, 57, 23);
        panel.add(btn59);
        btn59.addActionListener(this);

        JButton btn60 = new JButton("60");
        btn60.setForeground(new Color(255, 255, 255));
        btn60.setBackground(new Color(128, 0, 255));
        btn60.setBounds(373, 371, 57, 23);
        panel.add(btn60);
        btn60.addActionListener(this);

        JButton btn61 = new JButton("61");
        btn61.setForeground(new Color(255, 255, 255));
        btn61.setBackground(new Color(128, 0, 255));
        btn61.setBounds(277, 394, 57, 23);
        panel.add(btn61);
        btn61.addActionListener(this);

        JButton btn62 = new JButton("62");
        btn62.setForeground(new Color(255, 255, 255));
        btn62.setBackground(new Color(128, 0, 255));
        btn62.setBounds(373, 394, 57, 23);
        panel.add(btn62);
        btn62.addActionListener(this);

        JButton btn63 = new JButton("63");
        btn63.setForeground(new Color(255, 255, 255));
        btn63.setBackground(new Color(128, 0, 255));
        btn63.setBounds(508, 394, 57, 23);
        panel.add(btn63);
        btn63.addActionListener(this);

        JButton btn64 = new JButton("64");
        btn64.setForeground(new Color(255, 255, 255));
        btn64.setBackground(new Color(128, 0, 255));
        btn64.setBounds(604, 394, 57, 23);
        panel.add(btn64);
        btn64.addActionListener(this);

        JButton btn17 = new JButton("17");
        btn17.setForeground(new Color(255, 255, 255));
        btn17.setBackground(new Color(128, 0, 255));
        btn17.setBounds(277, 92, 57, 23);
        panel.add(btn17);
        btn17.addActionListener(this);

        JButton btn19 = new JButton("19");
        btn19.setForeground(new Color(255, 255, 255));
        btn19.setBackground(new Color(128, 0, 255));
        btn19.setBounds(277, 125, 57, 23);
        panel.add(btn19);
        btn19.addActionListener(this);

        JButton btn21 = new JButton("21");
        btn21.setForeground(new Color(255, 255, 255));
        btn21.setBackground(new Color(128, 0, 255));
        btn21.setBounds(277, 158, 57, 23);
        panel.add(btn21);
        btn21.addActionListener(this);

        JButton btn23 = new JButton("23");
        btn23.setForeground(new Color(255, 255, 255));
        btn23.setBackground(new Color(128, 0, 255));
        btn23.setBounds(277, 193, 57, 23);
        panel.add(btn23);
        btn23.addActionListener(this);

        JButton btn25 = new JButton("25");
        btn25.setForeground(new Color(255, 255, 255));
        btn25.setBackground(new Color(128, 0, 255));
        btn25.setBounds(277, 226, 57, 23);
        panel.add(btn25);
        btn25.addActionListener(this);

        JButton btn27 = new JButton("27");
        btn27.setForeground(new Color(255, 255, 255));
        btn27.setBackground(new Color(128, 0, 255));
        btn27.setBounds(277, 259, 57, 23);
        panel.add(btn27);
        btn27.addActionListener(this);

        JButton btn29 = new JButton("29");
        btn29.setForeground(new Color(255, 255, 255));
        btn29.setBackground(new Color(128, 0, 255));
        btn29.setBounds(277, 292, 57, 23);
        panel.add(btn29);
        btn29.addActionListener(this);

        JButton btn31 = new JButton("31");
        btn31.setForeground(new Color(255, 255, 255));
        btn31.setBackground(new Color(128, 0, 255));
        btn31.setBounds(277, 325, 57, 23);
        panel.add(btn31);
        btn31.addActionListener(this);

        JButton btn32 = new JButton("32");
        btn32.setForeground(new Color(255, 255, 255));
        btn32.setBackground(new Color(128, 0, 255));
        btn32.setBounds(373, 325, 57, 23);
        panel.add(btn32);
        btn32.addActionListener(this);

        JButton btn30 = new JButton("30");
        btn30.setForeground(new Color(255, 255, 255));
        btn30.setBackground(new Color(128, 0, 255));
        btn30.setBounds(373, 292, 57, 23);
        panel.add(btn30);
        btn30.addActionListener(this);

        JButton btn28 = new JButton("28");
        btn28.setForeground(new Color(255, 255, 255));
        btn28.setBackground(new Color(128, 0, 255));
        btn28.setBounds(373, 259, 57, 23);
        panel.add(btn28);
        btn28.addActionListener(this);

        JButton btn26 = new JButton("26");
        btn26.setForeground(new Color(255, 255, 255));
        btn26.setBackground(new Color(128, 0, 255));
        btn26.setBounds(373, 226, 57, 23);
        panel.add(btn26);
        btn26.addActionListener(this);

        JButton btn24 = new JButton("24");
        btn24.setForeground(new Color(255, 255, 255));
        btn24.setBackground(new Color(128, 0, 255));
        btn24.setBounds(373, 193, 57, 23);
        panel.add(btn24);
        btn24.addActionListener(this);

        JButton btn22 = new JButton("22");
        btn22.setForeground(new Color(255, 255, 255));
        btn22.setBackground(new Color(128, 0, 255));
        btn22.setBounds(373, 158, 57, 23);
        panel.add(btn22);
        btn22.addActionListener(this);

        JButton btn20 = new JButton("20");
        btn20.setForeground(new Color(255, 255, 255));
        btn20.setBackground(new Color(128, 0, 255));
        btn20.setBounds(373, 125, 57, 23);
        panel.add(btn20);
        btn20.addActionListener(this);

        JButton btn18 = new JButton("18");
        btn18.setForeground(new Color(255, 255, 255));
        btn18.setBackground(new Color(128, 0, 255));
        btn18.setBounds(373, 92, 57, 23);
        panel.add(btn18);
        btn18.addActionListener(this);

        JButton btn47 = new JButton("47");
        btn47.setForeground(new Color(255, 255, 255));
        btn47.setBackground(new Color(128, 0, 255));
        btn47.setBounds(508, 325, 57, 23);
        panel.add(btn47);
        btn47.addActionListener(this);

        JButton btn45 = new JButton("45");
        btn45.setForeground(new Color(255, 255, 255));
        btn45.setBackground(new Color(128, 0, 255));
        btn45.setBounds(508, 292, 57, 23);
        panel.add(btn45);
        btn45.addActionListener(this);

        JButton btn43 = new JButton("43");
        btn43.setForeground(new Color(255, 255, 255));
        btn43.setBackground(new Color(128, 0, 255));
        btn43.setBounds(508, 259, 57, 23);
        panel.add(btn43);
        btn43.addActionListener(this);

        JButton btn41 = new JButton("41");
        btn41.setForeground(new Color(255, 255, 255));
        btn41.setBackground(new Color(128, 0, 255));
        btn41.setBounds(508, 226, 57, 23);
        panel.add(btn41);
        btn41.addActionListener(this);

        JButton btn39 = new JButton("39");
        btn39.setForeground(new Color(255, 255, 255));
        btn39.setBackground(new Color(128, 0, 255));
        btn39.setBounds(508, 193, 57, 23);
        panel.add(btn39);
        btn39.addActionListener(this);

        JButton btn37 = new JButton("37");
        btn37.setForeground(new Color(255, 255, 255));
        btn37.setBackground(new Color(128, 0, 255));
        btn37.setBounds(508, 158, 57, 23);
        panel.add(btn37);
        btn37.addActionListener(this);

        JButton btn35 = new JButton("35");
        btn35.setForeground(new Color(255, 255, 255));
        btn35.setBackground(new Color(128, 0, 255));
        btn35.setBounds(508, 125, 57, 23);
        panel.add(btn35);
        btn35.addActionListener(this);

        JButton btn33 = new JButton("33");
        btn33.setForeground(new Color(255, 255, 255));
        btn33.setBackground(new Color(128, 0, 255));
        btn33.setBounds(508, 92, 57, 23);
        panel.add(btn33);
        btn33.addActionListener(this);

        JButton btn34 = new JButton("34");
        btn34.setForeground(new Color(255, 255, 255));
        btn34.setBackground(new Color(128, 0, 255));
        btn34.setBounds(604, 92, 57, 23);
        panel.add(btn34);
        btn34.addActionListener(this);

        JButton btn36 = new JButton("36");
        btn36.setForeground(new Color(255, 255, 255));
        btn36.setBackground(new Color(128, 0, 255));
        btn36.setBounds(604, 125, 57, 23);
        panel.add(btn36);
        btn36.addActionListener(this);

        JButton btn38 = new JButton("38");
        btn38.setForeground(new Color(255, 255, 255));
        btn38.setBackground(new Color(128, 0, 255));
        btn38.setBounds(604, 158, 57, 23);
        panel.add(btn38);
        btn38.addActionListener(this);

        JButton btn40 = new JButton("40");
        btn40.setForeground(new Color(255, 255, 255));
        btn40.setBackground(new Color(128, 0, 255));
        btn40.setBounds(604, 193, 57, 23);
        panel.add(btn40);
        btn40.addActionListener(this);

        JButton btn42 = new JButton("42");
        btn42.setForeground(new Color(255, 255, 255));
        btn42.setBackground(new Color(128, 0, 255));
        btn42.setBounds(604, 226, 57, 23);
        panel.add(btn42);
        btn42.addActionListener(this);

        JButton btn44 = new JButton("44");
        btn44.setForeground(new Color(255, 255, 255));
        btn44.setBackground(new Color(128, 0, 255));
        btn44.setBounds(604, 259, 57, 23);
        panel.add(btn44);
        btn44.addActionListener(this);

        JButton btn46 = new JButton("46");
        btn46.setForeground(new Color(255, 255, 255));
        btn46.setBackground(new Color(128, 0, 255));
        btn46.setBounds(604, 292, 57, 23);
        panel.add(btn46);
        btn46.addActionListener(this);

        JButton btn48 = new JButton("48");
        btn48.setForeground(new Color(255, 255, 255));
        btn48.setBackground(new Color(128, 0, 255));
        btn48.setBounds(604, 325, 57, 23);
        panel.add(btn48);
        btn48.addActionListener(this);

        JButton btn66 = new JButton("66");
        btn66.setForeground(new Color(255, 255, 255));
        btn66.setBackground(new Color(128, 0, 255));
        btn66.setBounds(809, 394, 57, 23);
        panel.add(btn66);
        btn66.addActionListener(this);

        JButton btn65 = new JButton("65");
        btn65.setForeground(new Color(255, 255, 255));
        btn65.setBackground(new Color(128, 0, 255));
        btn65.setBounds(713, 394, 57, 23);
        panel.add(btn65);
        btn65.addActionListener(this);

        JButton btn54 = new JButton("54");
        btn54.setForeground(new Color(255, 255, 255));
        btn54.setBackground(new Color(128, 0, 255));
        btn54.setBounds(809, 158, 57, 23);
        panel.add(btn54);
        btn54.addActionListener(this);

        JButton btn53 = new JButton("53");
        btn53.setForeground(new Color(255, 255, 255));
        btn53.setBackground(new Color(128, 0, 255));
        btn53.setBounds(713, 158, 57, 23);
        panel.add(btn53);
        btn53.addActionListener(this);

        JButton btn52 = new JButton("52");
        btn52.setForeground(new Color(255, 255, 255));
        btn52.setBackground(new Color(128, 0, 255));
        btn52.setBounds(808, 125, 57, 23);
        panel.add(btn52);

        JButton btn51 = new JButton("51");
        btn51.setForeground(new Color(255, 255, 255));
        btn51.setBackground(new Color(128, 0, 255));
        btn51.setBounds(712, 125, 57, 23);
        panel.add(btn51);
        btn51.addActionListener(this);

        JButton btn50 = new JButton("50");
        btn50.setForeground(new Color(255, 255, 255));
        btn50.setBackground(new Color(128, 0, 255));
        btn50.setBounds(809, 92, 57, 23);
        panel.add(btn50);
        btn50.addActionListener(this);

        JButton btn49 = new JButton("49");
        btn49.setForeground(new Color(255, 255, 255));
        btn49.setBackground(new Color(128, 0, 255));
        btn49.setBounds(713, 92, 57, 23);
        panel.add(btn49);
        btn49.addActionListener(this);

        bar = new MenuBar();
        file = new Menu("메뉴");
        file.add("내정보");
        file.add("채팅방");
        file.add("메뉴판");
        file.add("로그아웃");
        bar.add(file);
        setMenuBar(bar);

        file.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cmd = e.getActionCommand();
                if(cmd.equals("내정보")) {
                    System.out.println("내정보");
                    MyPage.setBean(mbean);
                    page = new MyPage();
                    page.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosing(WindowEvent e) {
                            super.windowClosing(e);
                            page.setVisible(false);
                            page.dispose();
                        }
                    });
                }else if(cmd.equals("채팅방")) {
                    if (game==null) {
                        game.setBean(mbean);
                        game = new Game();
                    }else {
                        game.setVisible(true);
                    }
                }else if(cmd.equals("메뉴판")) {
                    MenuPan.setMemberBean(mbean);
                    MenuPan.setLocalPcBean(pcbean);
                    menu = new MenuPan();
                    menu.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosing(WindowEvent e) {
                            super.windowClosing(e);
                            menu.setVisible(false);
                            menu.dispose();
                        }
                    });
                }else if(cmd.equals("로그아웃")) {
                    LoginHome lh = new LoginHome();
                    dispose();
                }
            }
        });
        setResizable(false);
        setVisible(true);
        validate();
    }

    public static void setMemberBean(MemberBean bean) {
        SelectSeat.mbean = bean;
    }

    public static void setLocalPcBean(LocalPcBean bean) {
        SelectSeat.pcbean = bean;
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        // 이벤트를 트리거한 JButton의 텍스트 가져오기
        String seatNum = ((JButton) e.getSource()).getText();

        // pcseatbean 객체에 좌석 번호 설정하기
        pcseatbean.setSeat_Num(Integer.parseInt(seatNum));

        seat.setMemberBean(mbean);
        seat.setPcBean(pcbean);
        seat.setPcSeatBean(pcseatbean);
        seat = new Seat_Box();
    }

    public static void main(String[] args) {
        pcbean = new LocalPcBean();
        MemberBean mbean = new MemberBean();
        MemberMgr mmgr = new MemberMgr();
        mbean = mmgr.mapUserInfo(args[2]);
        LocalPcBean pcbean = new LocalPcBean();
        LocalMgr lmgr = new LocalMgr();

        pcbean = lmgr.selectPcNum(Integer.parseInt(args[0]));
        String cen = pcbean.getLocal_pcName().trim();
        pcbean.setLocal_pcName(cen);
        SelectSeat.setMemberBean(mbean);
        SelectSeat.setLocalPcBean(pcbean);

        new SelectSeat();
    }
}
