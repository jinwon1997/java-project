package form;

import bean.MemberBean;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.net.Socket;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class ChatClient extends JFrame
        implements ActionListener, Runnable {

    JButton  listBtn, msgBtn, saveBtn,  sendBtn;
    JTextField sendTf;
    TextArea contentArea;
    List chatList;
    Socket sock;
    BufferedReader in;
    PrintWriter out;
    String title = ChatProtocol.GAMENAME+" 채팅방";
    String listTitle = "*****채팅 참가자*****";
    boolean flag = false;
    String id;
    String label[] = {"쪽지 보내기","전송","뒤로가기"};
    ChatAWT chatAWT;
    private static MemberBean mbean;
    Game game;
    String today;
    int cnt = 0;
    Timer tm = new Timer();
    int j;
    int k;

    public ChatClient(BufferedReader in, PrintWriter out, String id) {
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        /*닫기 버튼을 비활성화시켰습니다. 닫았을 때 대화내용 저장을 Hook를 통해 조정하려니
         * 계속해서 순서 문제가 발생하여 차라리 뒤로가기 버튼을 눌렀을 때 처리하도록 변경하였습니다.*/
        this.in = in;
        this.out = out;
        this.id = id;
        setTitle(title);
        contentArea = new TextArea();
        contentArea.setBackground(Color.DARK_GRAY);
        contentArea.setForeground(Color.GREEN);
        contentArea.setEditable(false);
        add(BorderLayout.CENTER, contentArea);
        // /////////////////////////////////////////////////////////////////////////////////////////
        Panel p2 = new Panel();
        p2.setLayout(new BorderLayout());
        chatList = new List();
        chatList.add(listTitle);
        p2.add(BorderLayout.CENTER, chatList);
        Panel p3 = new Panel();
        msgBtn = new JButton(label[0]);
        msgBtn.addActionListener(this);
        p3.add(msgBtn);
        p2.add(BorderLayout.SOUTH, p3);
        add(BorderLayout.EAST, p2);
        ChatProtocol.PASTLOG = "";
        // ///////////////////////////////////////////////////////////////////////////////////////////
        Panel p4 = new Panel();
        sendTf = new JTextField("", 24);
        sendTf.addActionListener(this);
        sendBtn = new JButton(label[1]);
        sendBtn.addActionListener(this);
        saveBtn = new JButton(label[2]);
        saveBtn.addActionListener(this);
        p4.add(sendTf);
        p4.add(sendBtn);
        p4.add(saveBtn);
        add(BorderLayout.SOUTH, p4);
        sendTf.requestFocus();
        setVisible(true);
        setBean(mbean);
        validate();
        // ///////////////////////////////////////////////////////////////////////////////////////////
        /*밑의 코드는 텍스트 파일을 불러오는 코드입니다.*/
        try {
            File file = new File("C:\\Users\\dita810\\Documents\\Chat\\");
            File fileList[] = file.listFiles();
            String fileName;
            File txt = null;

            for(int i = 0; i<fileList.length; i++){
                fileName = fileList[i].toString();
                if(fileName.contains(mbean.getUserId()+ChatProtocol.GAMENAME + ".txt")){
                    txt = fileList[i];
                }
            }
            FileReader fileReader = new FileReader(txt);
            BufferedReader br = new BufferedReader(fileReader);
            String line = "";
            today = day();
            while ((line=br.readLine())!=null) {
                if (line.contains("[" + mbean.getUserId() + "]님이 입장하였습니다")) {
                    //[아이디]님이 입장하였습니다.와 ------------------는 재차 출력하지 않음.
                } else if ((line.trim().equals(today.trim()))&&cnt==0) {
                    ChatProtocol.PASTLOG += line + "\n";
                    cnt++;
                } else if (line.trim().equals(today) && cnt != 0) {
                } else {
                    ChatProtocol.PASTLOG += line + "\n";
                }
            }
            contentArea.append(ChatProtocol.PASTLOG);
            if(cnt==0){
                contentArea.append(" ------------------------\n"+today+"\n ------------------------\n");
            }
            br.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        new Thread(this).start();

        //1초마다 채팅방 내용을 자동으로 저장해주는 기능
        TimerTask task = new TimerTask() {
            @Override
            public void run(){
                try{
                    //System.out.println("텍스트를 저장하습니다.");
                    String path = "C:\\Users\\dita810\\Documents\\Chat"; //폴더 경로
                    File Folder = new File(path);

                    // 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
                    if (!Folder.exists()) {
                        try{
                            Folder.mkdir(); //폴더 생성합니다.
                            System.out.println("폴더가 생성되었습니다.");
                        }
                        catch(Exception e3){
                            e3.getStackTrace();
                        }
                    }
                    FileWriter fw = new FileWriter("C:\\Users\\dita810\\Documents\\Chat\\"+mbean.getUserId()+ChatProtocol.GAMENAME+".txt");
                    fw.write(contentArea.getText());
                    fw.close();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
            }
        };
        tm.scheduleAtFixedRate(task, 1000, 1000);
    }

    public void run() {
        try {
            while (true) {
                String line = in.readLine();
                if (line == null)
                    break;
                else
                    routine(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//--run

    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj==saveBtn/*이름은 저장 버튼이지만 뒤로가기로 바꿨습니다.*/) {
            tm.cancel(); //채팅방을 나가면 1초마다 자동 저장하는 기능을 멈춥니다.
            try{
                System.out.println("텍스트를 저장하습니다.");
                String path = "C:\\Users\\dita810\\Documents\\Chat"; //폴더 경로
                File Folder = new File(path);

                // 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
                if (!Folder.exists()) {
                    try{
                        Folder.mkdir(); //폴더 생성합니다.
                        System.out.println("폴더가 생성되었습니다.");
                    }
                    catch(Exception e3){
                        e3.getStackTrace();
                    }
                }
                FileWriter fw = new FileWriter("C:\\Users\\dita810\\Documents\\Chat\\"+mbean.getUserId()+ChatProtocol.GAMENAME+".txt");
                fw.write(contentArea.getText());
                fw.close();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            // 퇴장 정보 서버로 전송
//            sendMessage(ChatProtocol.CHAT + ChatProtocol.MODE + "방을 나갔습니다.");
            sendMessage(ChatProtocol.CHATOUT+ChatProtocol.MODE);
            dispose();
        }else if(obj==listBtn) {
            sendMessage(ChatProtocol.MSGLIST+
                    ChatProtocol.MODE+id);
        }else if(obj==msgBtn/*message*/) {
            int i = chatList.getSelectedIndex();
            if(i==-1||i==0) {
                new MDialog(this, "알림", "아이디를 선택하세요.");
            }else {
                new Message("TO");
            }
        }else if(obj==sendBtn ||obj==sendTf) {
            String str = sendTf.getText();
            if(filterMgr(str)) {
                new MDialog(this, "경고", "입력하신 글자는 금지어입니다.");
                return;
            }
            int i = chatList.getSelectedIndex();
            if(i==-1||i==0) {//전체채팅
                sendMessage(ChatProtocol.CHATALL+ChatProtocol.MODE+str);
            }else { //귓속말 채팅
                String id = chatList.getSelectedItem();
                sendMessage(ChatProtocol.CHAT+ChatProtocol.MODE+id+";"+str);
            }
            sendTf.setText("");
            sendTf.requestFocus();
        }
    }//--actionPerformed

    public void routine(String line) {
        int idx = line.indexOf(ChatProtocol.MODE);
        String cmd = line.substring(0, idx);
        String data = line.substring(idx+1);
        if(cmd.equals(ChatProtocol.CHATLIST)) {
            chatList.removeAll();
//            chatList.add(listTitle);
            for(int i=0; i<11; i++) {
                if(ChatProtocol.GAMENAME2[i].equals(ChatProtocol.GAMENAME)){
                    j=i;
                    ChatServer.user_num[i]=0;
                    break;
                }
            }
            StringTokenizer st = new StringTokenizer(data, ";");
            k=0;
            while(st.hasMoreTokens()) {
                chatList.add(st.nextToken());
                k++;
            }
            ChatServer.user_num[j]=k;
            chatList.add("현 인원수 [ "+String.valueOf(ChatServer.user_num[j]+" ] 명"),0);
        }else if(cmd.equals(ChatProtocol.CHAT)||
                cmd.equals(ChatProtocol.CHATALL)){
            contentArea.append(data+"\n");
        }else if(cmd.equals(ChatProtocol.MESSAGE)){
            idx = data.indexOf(';');
            cmd = data.substring(0,idx);
            data = data.substring(idx+1);
            new Message("FROM", cmd, data);
        }else if(cmd.equals(ChatProtocol.MSGLIST)){
            chatAWT = new ChatAWT(this, data);
        }
    }//--routine

    public void sendMessage(String msg) {
        out.println(msg);
    }

    public boolean filterMgr(String msg){
        boolean flag = false;//false이면 금지어 아님
        String str[] = {"바보","개새끼","새끼","자바","java"};
        //msg : 하하 호호 히히
        StringTokenizer st = new StringTokenizer(msg);//생략하면 구분자는 공백
        String msgs[] = new String[st.countTokens()];
        for (int i = 0; i < msgs.length; i++) {
            msgs[i] = st.nextToken();
        }
        for (int i = 0; i < str.length; i++) {
            if(flag) break;//첫번째 for문 빠져나감.
            for (int j = 0; j < msgs.length; j++) {
                if(str[i].equalsIgnoreCase(msgs[j])) {
                    flag = true;
                    break; //두번째 for문 빠져나감.
                }//if
            }//for2
        }//for1
        return flag;
    }

    class Message extends Frame implements ActionListener {

        Button send, resend;
        TextField name;
        TextArea ta;
        String mode;// to/from
        String id;

        public Message(String mode) {
            setTitle("쪽지보내기");
            this.mode = mode;
            id = chatList.getSelectedItem();
            layset("");
            validate();
        }
        public Message(String mode, String id, String msg) {
            setTitle("쪽지읽기");
            this.mode = mode;
            this.id = id;
            layset(msg);
            validate();
        }
        public Message(String mode, String id) {
            setTitle("쪽지답장");
            this.mode = mode;
            this.id = id;
            layset("");
            validate();
        }
        public void layset(String msg) {
            addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    dispose();
                }
            });
            Panel p1 = new Panel();
            p1.add(new Label(mode, Label.CENTER));
            name = new TextField(id, 20);
            p1.add(name);
            add(BorderLayout.NORTH, p1);

            ta = new TextArea("");
            add(BorderLayout.CENTER, ta);
            ta.setText(msg);
            Panel p2 = new Panel();
            if (mode.equals("TO")) {
                p2.add(send = new Button("쪽지 보내기"));
                send.addActionListener(this);
            } else if (mode.equals("FROM")) {
                p2.add(resend = new Button("답장 하기"));
                resend.addActionListener(this);
            }
            add(BorderLayout.SOUTH, p2);

            setBounds(200, 200, 250, 250);
            setVisible(true);
        }

        public void actionPerformed(ActionEvent e) {
            if(e.getSource()==send){
                sendMessage(ChatProtocol.MESSAGE+":"+id+";"+ ta.getText());
            } else if(e.getSource()==resend) {
                new Message("TO", id);
            }
            setVisible(false);
//         dispose();
        }
    }

    class MDialog extends Dialog implements ActionListener{

        Button ok;
        ChatClient ct;

        public MDialog(ChatClient ct,String title, String msg) {
            super(ct, title, true);
            this.ct = ct;
            //////////////////////////////////////////////////////////////////////////////////////////
            addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    dispose();
                }
            });
            /////////////////////////////////////////////////////////////////////////////////////////
            setLayout(new GridLayout(2,1));
            Label label = new Label(msg, Label.CENTER);
            add(label);
            add(ok = new Button("확인"));
            ok.addActionListener(this);
            layset();
            setVisible(true);
            validate();
        }

        public void layset() {
            int width = 200;
            int height = 100;
            setSize(width, height);
            setLocationRelativeTo(ct);
            setVisible(true);
        }

        public void actionPerformed(ActionEvent e) {
            sendTf.setText("");
            dispose();
        }
    }

    public static void setBean(MemberBean bean) {
        ChatClient.mbean = bean;
    }

    public String day(){
        long current = System.currentTimeMillis();

        Date currentDate = new Date(current);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int yoil = calendar.get(Calendar.DAY_OF_WEEK);
        String weekday;
        switch (yoil) {
            case 1: {
                weekday="일요일";
                break;
            }
            case 2: {
                weekday="월요일";
                break;
            }
            case 3: {
                weekday="화요일";
                break;
            }
            case 4: {
                weekday="수요일";
                break;
            }
            case 5: {
                weekday="목요일";
                break;
            }
            case 6: {
                weekday="금요일";
                break;
            }
            case 7: {
                weekday="토요일";
                break;
            }
            default:
                throw new IllegalArgumentException("Unexpected value: " + yoil);
        }
        today = " | "+year+"년 "+month+"월 "+day+"일 "+weekday+" |";
        return today;
    }
}