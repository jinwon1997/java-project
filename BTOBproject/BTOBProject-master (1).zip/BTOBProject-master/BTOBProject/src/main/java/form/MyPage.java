package form;

import DB.LocalMgr;
import DB.MemberMgr;
import bean.LocalBean;
import bean.MemberBean;

import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.Vector;

public class MyPage extends JFrame {

    private static MemberBean bean;
    JPanel p;
    JLabel id,name, point, lbllocal, lbladdress,lblpoint, lblphone, lblname, lblid;
    JTextField address, phone, point2;
    JButton charge, confirm, back, paymentList;
    Choice ch;
    LocalMgr localmgr;
    MemberMgr memberMgr;
    MemberBean mbean;
    Vector<LocalBean> localvlist;
    int money;
    PaymentList pl;

    public MyPage()  {
        memberMgr = new MemberMgr();
        mbean = new MemberBean();

        setForeground(new Color(0, 0, 0));
        setBounds(100, 100, 500, 370);
        getContentPane().setLayout(null);

        p = new JPanel();
        p.setBackground(new Color(255,255,255));
        p.setBounds(123, 0, 341, 284);
        getContentPane().add(p);
        p.setLayout(null);

        id = new JLabel(bean.getUserId());
        id.setBounds(25, 70, 142, 15);
        p.add(id);

        name = new JLabel(bean.getName());
        name.setBounds(25, 27, 142, 15);
        p.add(name);


        address = new JTextField();
        address.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                address.setText("");
            }
        });
        address.setText(bean.getAddress());
        address.setBounds(25, 155, 116, 21);
        p.add(address);
        address.setColumns(10);

        phone = new JTextField();
        phone.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                phone.setText("");
            }
        });
        phone.setText(bean.getPhone());
        phone.setColumns(10);
        phone.setBounds(25, 197, 116, 21);
        p.add(phone);

        point2 = new JTextField();
        point2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                point2.setText("");
            }
        });
        point2.setText("충전할 금액");
        point2.setColumns(10);
        point2.setBounds(110, 238, 116, 21);
        p.add(point2);

        money = bean.getUserCharge();
        point = new JLabel(String.valueOf(money));
        point.setBounds(25, 242, 115, 15);
        p.add(point);

        paymentList = new JButton("결제내역 보기");
        paymentList.setBounds(210, 197, 120, 23);
        p.add(paymentList);
        paymentList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pl.setBean(bean);
                pl = new PaymentList();
            }
        });

        charge = new JButton("충전하기");
        charge.setBounds(233, 238, 90, 23);
        p.add(charge);

        ch = new Choice();
        localmgr = new LocalMgr();
        localvlist = localmgr.getLocalname();
        String localname[] = new String[localvlist.size()];
        for (int i = 0; i < localvlist.size(); i++) {
            LocalBean localbean = localvlist.get(i);
            localname[i] = localbean.getLocalName();
            ch.add(localname[i]);
        }
        ch.setBounds(25, 113, 142, 15);
        p.add(ch);

        lbllocal = new JLabel("주소");
        lbllocal.setBounds(12, 112, 57, 15);
        add(lbllocal);

        lbladdress = new JLabel("상세주소");
        lbladdress.setBounds(12, 154, 57, 15);
        add(lbladdress);

        lblphone = new JLabel("전화번호");
        lblphone.setBounds(12, 198, 57, 15);
        getContentPane().add(lblphone);

        lblpoint = new JLabel("잔여 포인트");
        lblpoint.setBounds(12, 239, 87, 15);
        add(lblpoint);

        confirm = new JButton("확인");
        confirm.setBounds(79, 294, 97, 23);
        add(confirm);

        back = new JButton("뒤로가기");
        back.setBounds(206, 294, 97, 23);
        add(back);


        lblname = new JLabel("이름");
        lblname.setBounds(12, 28, 57, 15);
        add(lblname);

        lblid = new JLabel("아이디");
        lblid.setBounds(12, 67, 57, 15);
        add(lblid);

        confirm.addActionListener(this::actionPerformed);
        charge.addActionListener(this::actionPerformed);
        back.addActionListener(this::actionPerformed);

        setVisible(true);
        setResizable(false);
        validate();
    }


    public void actionPerformed(ActionEvent e) {
        int pnt = bean.getUserCharge(); //유저의 정보에 담겨있던 포인트
        Object obj = e.getSource();
        if(obj == confirm){
            int res = JOptionPane.showConfirmDialog(null, "수정 하시겠습니까?", "알림", JOptionPane.YES_NO_OPTION);
            if(res==JOptionPane.YES_OPTION) {
                memberMgr = new MemberMgr();
                mbean = new MemberBean();
                setBean(bean); //유저정보 담기
                mbean.setLocalNum(ch.getSelectedIndex()+1); //선택되는 getSelectedIndex+1로 local_num 지정
                mbean.setAddress(address.getText());
                mbean.setPhone(phone.getText());
                mbean.setUserId(bean.getUserId());
                System.out.println(mbean);
                memberMgr.updateUser(mbean); //유저정보 update
                JOptionPane.showMessageDialog(null, "수정 완료하였습니다.", "알림", JOptionPane.WARNING_MESSAGE);
            }
        }else if(obj == charge){
            int money = Integer.parseInt(point2.getText()); //충전하고 싶은 금액
            pnt += money; //충전개념으로 합산
            mbean.setUserCharge(pnt); //set
            mbean.setUserId(bean.getUserId()); //user_id
            memberMgr.updateCharge(mbean); //update
            bean = memberMgr.getUserInfo(mbean);
            money = bean.getUserCharge();
            point.setText(String.valueOf(money));
            JOptionPane.showMessageDialog(null, "충전이 완료 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
        }else if(obj == back){
            dispose();
        }
    }

    public static void setBean(MemberBean bean) {
        MyPage.bean = bean;
    }

}