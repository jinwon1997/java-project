package form;

import lombok.Data;

public class ChatProtocol {
    public static final String ID = "ID";
    public static final String CHAT = "CHAT";
    public static final String CHATALL = "CHATALL";
    public static final String CHATLIST = "CHATLIST";
    public static final String MESSAGE = "MESSAGE";
    public  static final String MSGLIST = "MSGLIST";
    public static final String MODE = ":";
    public static int PORT = 8101;
    public static String GAMENAME = "GAMENAME";
    public static String PASTLOG = "";
    public static String CHATOUT = "CHATOUT";
    public static String[] GAMENAME2 = {"리그 오브 레전드", "메이플스토리", "피파온라인4", "발로란트", "서든어택",
            "오버워치2", "디아블로4", "배틀그라운드", "로스트아크", "스타크래프트", "기타"};
}