package form;


import DB.MemberMgr;
import bean.MemberBean;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Findpassword extends JFrame
        implements ActionListener{

    LoginHome lf;
    JLabel lbl1, lbl2, lbl3;
    JButton btn1, btn2;
    JTextField tf1, tf2, tf3;
    DialogBox err1;
    MemberMgr mgr;
    MemberBean bean;

    public Findpassword() {
        setTitle("비밀번호 찾기");
        setBounds(100, 100, 350, 270);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().setBackground(new Color(172, 255, 146));

        tf1 = new JTextField("이름 입력");
        tf1.setBounds(55, 50, 220, 30);
        getContentPane().add(tf1);

        tf2 = new JTextField("주민번호 입력");
        tf2.setBounds(55, 80, 220, 30);
        getContentPane().add(tf2);

        tf3 = new JTextField("아이디 입력");
        tf3.setBounds(55, 110, 220, 30);
        getContentPane().add(tf3);

        btn1 = new JButton("확인");
        btn1.setBounds(55, 140, 220, 30);
        getContentPane().add(btn1);

        btn2 = new JButton("취소");
        btn2.setBounds(55, 170, 220, 30);
        getContentPane().add(btn2);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
        setResizable(false);
        setVisible(true);
        validate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        mgr = new MemberMgr();
        String name = tf1.getText();
        String social = tf2.getText();
        String id = tf3.getText();

        if (obj == btn1) {
            if(name.equals(mgr.getFindPassword(name,social,id).getName()) &&
                    social.equals(mgr.getFindPassword(name,social,id).getSocialNum())
                    && id.equals(mgr.getFindPassword(name,social,id).getUserId())) {
                bean = new MemberBean();
                bean.setName(name);
                bean.setSocialNum(social);
                bean.setUserId(id);
                System.out.println(bean.toString());
                UpdatePassword updatePassword = new UpdatePassword();
                updatePassword.setBean(bean);
                this.dispose();
            }else {
                err1 = new DialogBox(this, "올바르지 않은 정보입니다.","알림");
            }
        } else if (obj == btn2) {
            lf = new LoginHome();
            lf.setLocation(getX(),getY());
            dispose();
        }
    }

    public static void main(String[] args) {
        new Findpassword();
    }
}
