package form;

import DB.MemberMgr;
import bean.LocalBean;
import DB.LocalMgr;
import bean.MemberBean;
import security.Encryption;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.swing.*;


public class CreateMember extends JFrame
		implements ActionListener,ItemListener{

	JButton btn1, btn2, btn3;
	LoginHome lf;
	DialogBox err1, err2;
	JTextField tf1, tf3, tf4, tf5, tf6;
	JPasswordField tf2;
	Vector<LocalBean> vlist;
	Vector<MemberBean> vlist2;
	JComboBox<String > ch;
	JCheckBox agr;
	LocalMgr mgr;
	JRadioButton gender1, gender2;
	ButtonGroup gender;
	JLabel itf1, itf2, itf3, itf4, itf5, itf5_2, itf6, itf7, logo;
	MemberMgr mgr2 = new MemberMgr();;
	ArrayList<String> arrayList = new ArrayList<String>();
	ArrayList<String> arrayList2 = new ArrayList<String>();
	int t1 = 0;

	public CreateMember() {
		setSize(1000,1000);
		setTitle("회원가입");
		getContentPane().setBackground(new Color(255, 255, 255));
		getContentPane().setFont(new Font("궁서체", Font.BOLD, 12));
		setBounds(100, 100, 471, 466);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		mgr = new LocalMgr();
		btn1 = new JButton("아이디 중복 확인");

		btn1.setBounds(289, 57, 150, 23);
		getContentPane().add(btn1);

		tf1 = new JTextField();
		tf1.setBounds(131, 57, 146, 21);
		getContentPane().add(tf1);
		tf1.setColumns(10);

		tf2 = new JPasswordField();
		tf2.setBounds(131, 91, 146, 21);
		tf2.setColumns(10);
		getContentPane().add(tf2);

		tf3 = new JTextField();
		tf3.setBounds(131, 132, 146, 21);
		tf3.setColumns(10);
		getContentPane().add(tf3);

		tf4 = new JTextField();
		tf4.setBounds(131, 165, 146, 21);
		tf4.setColumns(10);
		getContentPane().add(tf4);
		vlist = mgr.getLocalname();
		String str[] = new String[16];
		for (int i = 0; i < str.length; i++) {
			LocalBean bean = vlist.get(i);
			str[i]=bean.getLocalName().trim();
		}
		ch = new JComboBox<String>(str);
		ch.setBounds(131, 204, 146, 21);
		getContentPane().add(ch);

		tf5 = new JTextField();
		tf5.setBounds(131, 240, 146, 21);
		tf5.setColumns(10);
		getContentPane().add(tf5);

		tf6 = new JTextField();
		tf6.setBounds(131, 280, 146, 21);
		tf6.setColumns(10);
		getContentPane().add(tf6);

		btn2 = new JButton("회원가입");
		btn2.setBounds(69, 392, 97, 23);
		getContentPane().add(btn2);

		btn3 = new JButton("취소");
		btn3.setBounds(199, 392, 97, 23);
		getContentPane().add(btn3);

		gender1 = new JRadioButton("남성");
		gender1.setBackground(new Color(255, 255, 255));
		gender1.setBounds(131, 320, 64, 23);
		gender1.setSelected(true);
		getContentPane().add(gender1);
		gender2 = new JRadioButton("여성");
		gender2.setBackground(new Color(255, 255, 255));
		gender2.setBounds(209, 320, 68, 23);
		getContentPane().add(gender2);

		gender = new ButtonGroup();
		gender.add(gender1);
		gender.add(gender2);
		gender1.addItemListener(this);
		gender2.addItemListener(this);

		JLabel itf1 = new JLabel("아이디");
		itf1.setBounds(12, 57, 64, 15);
		getContentPane().add(itf1);

		JLabel itf2 = new JLabel("비밀번호");
		itf2.setBounds(12, 91, 64, 15);
		getContentPane().add(itf2);

		JLabel itf3 = new JLabel("이름");
		itf3.setBounds(12, 132, 64, 15);
		getContentPane().add(itf3);

		JLabel itf4 = new JLabel("주민등록번호");
		itf4.setBounds(12, 165, 107, 15);
		getContentPane().add(itf4);

		JLabel itf5 = new JLabel("주소");
		itf5.setBounds(12, 204, 64, 15);
		getContentPane().add(itf5);

		JLabel itf5_2 = new JLabel("상세주소");
		itf5_2.setBounds(12, 240, 64, 15);
		getContentPane().add(itf5_2);

		JLabel itf6 = new JLabel("전화번호");
		itf6.setBounds(12, 280, 64, 15);
		getContentPane().add(itf6);

		JLabel itf7 = new JLabel("성별");
		itf7.setBounds(12, 320, 33, 15);
		getContentPane().add(itf7);

		JLabel itf8 = new JLabel("동의여부");
		itf8.setBounds(12, 360, 60, 15);
		getContentPane().add(itf8);

		agr = new JCheckBox("승인");
		agr.setBounds(80, 360, 60, 15);
		getContentPane().add(agr);

		JLabel logo = new JLabel("BTOB 피시방 회원가입");
		logo.setForeground(new Color(0, 0, 0));
		logo.setFont(new Font("굴림", Font.PLAIN, 28));
		logo.setBackground(UIManager.getColor("CheckBox.foreground"));
		logo.setBounds(102, 1, 300, 46);
		getContentPane().add(logo);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 1, 455, 426);
		getContentPane().add(lblNewLabel);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		System.out.println(t1);
		//////////////////////////////////////
		setResizable(false);
		this.setVisible(true);
		validate();
	}
	@Override
	public void itemStateChanged(ItemEvent e) {

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == gender1) {
			t1 = 0;
			System.out.println(t1);
		}else if(obj == gender2){
			t1 = 1;
			System.out.println(t1);
		}
		Map<String, Integer> map = new HashMap<String, Integer>();
		for (int i = 0; i < 16; i++) {
			LocalBean bean = vlist.get(i);
			map.put(bean.getLocalName().trim(), i + 1);
		}
		if (obj == btn1) {
			String createid = tf1.getText().trim();
			if (createid.equals(mgr2.getUserIdList(createid).getUserId())) {
				err1 = new DialogBox(this, "이미 사용되어진 아이디입니다.", "알림");
				tf1.setText("");
				tf1.requestFocus();
			} else if (!createid.equals(mgr2.getUserIdList(createid).getUserId())) {
				err2 = new DialogBox(this, "사용 하실수 있습니다.", "알림");
				t1 = 1;
			}
		} else if (obj == btn2) {
			if (tf1.getText().trim().length() == 0 || t1 == 0) {
				DialogBox err3 = new DialogBox(this, "아이디를 입력해주세요.", "알림");
				tf1.requestFocus();
			} else if (tf2.getText().trim().length() == 0) {
				DialogBox err3 = new DialogBox(this, "비밀번호를 입력해주세요.", "알림");
				tf2.requestFocus();
			} else if (tf3.getText().trim().length() == 0) {
				DialogBox err3 = new DialogBox(this, "이름을 입력해주세요.", "알림");
				tf3.requestFocus();
			} else if (tf4.getText().trim().length() == 0) {
				DialogBox err3 = new DialogBox(this, "주민등록번호를 입력해주세요.", "알림");
				tf4.requestFocus();
			} else {
				MemberBean bean = new MemberBean();
				bean.setUserId(tf1.getText());
				try {
					bean.setUserPassword(Encryption.SHA256(tf2.getText()));
				} catch (Exception ex) {
					throw new RuntimeException(ex);
				}
				bean.setName(tf3.getText());
				bean.setSocialNum(tf4.getText());
				bean.setLocalNum(map.get(ch.getSelectedItem().toString()));
				bean.setAddress(tf5.getText());
				bean.setPhone(tf6.getText());
				bean.setGender(t1);
				if (mgr2.insertMember(bean)) {
					vlist.removeAllElements();
					DialogBox err3 = new DialogBox(this, "회원가입이 완료되었습니다.", "알림");
					setVisible(false);
					new LoginHome();
				}
			}
		}else if (obj == btn3) {
			lf = new LoginHome();
			dispose();
		}
	}
	public static void main(String[] args) {
		new CreateMember();
	}
}