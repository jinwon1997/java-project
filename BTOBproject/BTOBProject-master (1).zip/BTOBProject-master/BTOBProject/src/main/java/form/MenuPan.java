package form;

import DB.MemberMgr;
import DB.MenuMgr;
import bean.LocalPcBean;
import bean.MemberBean;
import bean.MenuBean;
import bean.MenuPocketBean;
import lombok.Data;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class MenuPan extends JFrame {
    private Map<String, CartItem> cartItems;
    MenuMgr menumgr;
    Vector<MenuBean> menuvlist;
    private JLabel totalLabel;
    private static MemberBean mbean;
    private static LocalPcBean pcbean;
    private static MenuPocketBean mpbean;
    DialogBox err1;
    Vector<MenuPocketBean> pocketList = new Vector<>();
    JButton payment, backbtn;
    public MenuPan() {
        setTitle("메뉴판");
        setLayout(new BorderLayout());
        cartItems = new HashMap<>();
        menumgr = new MenuMgr();
        menuvlist = menumgr.getMenuList();
        MemberMgr memberMgr = new MemberMgr();
        MenuPan.mbean = memberMgr.getUserInfo(mbean);
        // 메뉴판
        JPanel menuPanel = new JPanel(new GridLayout(3, 2));
        for (int i = 0; i < menuvlist.size(); i++) {
            MenuBean bean = menuvlist.get(i);
            String itemName = bean.getMenu_name();
            int itemPrice = bean.getMenu_price();
            ImageIcon img = new ImageIcon();
            if(bean.getMenu_image() != null){
                if (bean.getMenu_image().substring(0,4) != "http:" || bean.getMenu_image().substring(0,5) != "https:"){
                    try {
                        URL url = new URL(bean.getMenu_image());
                        img = new ImageIcon(url);
                        Image image = img.getImage().getScaledInstance(200, 150, Image.SCALE_SMOOTH); // 이미지 크기 조절
                        img.setImage(image);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                }
            }else{
                try {
                    URL url = new URL("https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2F20160402_19%2Fmaddara_1459606960178nrrdB_JPEG%2FUntitled-1.jpg&type=sc960_832");
                    img = new ImageIcon(url);
                    Image image = img.getImage().getScaledInstance(200, 150, Image.SCALE_SMOOTH); // 이미지 크기 조절
                    img.setImage(image);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
            JPanel menuItemPanel = createMenuItemPanel(bean);
            JButton menuItemButton = new JButton(itemName,img);
            menuItemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    addToCart(itemName, itemPrice);
                }
            });
            menuItemPanel.add(menuItemButton);
            menuPanel.add(menuItemPanel);
        }
        add(menuPanel, BorderLayout.CENTER);

        // 우측 패널 생성
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        // 유저 정보를 표시할 패널 생성
        JPanel userPanel = new JPanel(new GridLayout(2, 1));
        userPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 유저정보창
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JLabel userInfoLabel = new JLabel("User: " +  mbean.getUserId());
        topPanel.add(userInfoLabel);

        // 유저 정보 라벨
        JLabel pcLabel = new JLabel("피시방명: " + pcbean.getLocal_pcName());
        JLabel nameLabel = new JLabel("유저명: " + mbean.getUserId());
        JLabel chargeLabel = new JLabel("충전금액: " + mbean.getUserCharge());

        // 라벨을 패널에 추가
        userPanel.add(pcLabel);
        userPanel.add(nameLabel);
        userPanel.add(chargeLabel);

        // 카트 패널
        JPanel cartPanel = new JPanel();
        cartPanel.setLayout(new BoxLayout(cartPanel, BoxLayout.Y_AXIS));

        // totalLabel 초기화
        JPanel totalPanel = new JPanel();
        JLabel fLabel1 = new JLabel("총액 : ");
        totalPanel.add(fLabel1);
        totalLabel = new JLabel("0");
        totalPanel.add(totalLabel);
        payment = new JButton("결제하기");
        payment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int pnt = mbean.getUserCharge(); //유저의 정보에 담겨있던 포인트
                MemberMgr mgr = new MemberMgr();
                int money = Integer.parseInt(totalLabel.getText()); //충전하고 싶은 금액
                if (pnt >= money) {
                    JOptionPane.showMessageDialog(null, "결제가 완료되었습니다.","알림", JOptionPane.WARNING_MESSAGE);
                    pnt -= money;
                    mbean.setUserCharge(pnt); //set
                    mbean.setUserId(mbean.getUserId()); //user_id
                    mgr.updateCharge(mbean); //update
                    chargeLabel.setText(String.valueOf(mbean.getUserCharge()));
                    //장바구니 담는 코드
                    for (String key : cartItems.keySet()) {
                        mpbean = new MenuPocketBean();
                        CartItem cart = cartItems.get(key);
                        mpbean.setMenuName(cart.getItemName());
                        mpbean.setMenuCount(cart.getQuantity());
                        mpbean.setMenuPrice(cart.getItemPrice());
                        mpbean.setUserId(mbean.getUserId());
                        mpbean.setLocalpcNum(pcbean.getLocal_pcNum());
                        menumgr.insertPocket(mpbean);
                    }
                    clearCart();
                }else if(pnt<=money) {
                    JOptionPane.showMessageDialog(null, "잔액이 부족합니다","알림", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        JLabel fLabel2 = new JLabel("냥");
        totalPanel.add(fLabel2);
        backbtn = new JButton("뒤로가기");
        backbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });


        JPanel btnpanel = new JPanel();
        btnpanel.add(payment);
        btnpanel.add(backbtn);

        rightPanel.add(userPanel);
        rightPanel.add(cartPanel);
        rightPanel.add(totalPanel);
        rightPanel.add(btnpanel);
        add(rightPanel, BorderLayout.EAST);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        validate();
    }

    private JPanel createMenuItemPanel(MenuBean bean) {
        JPanel menuItemPanel = new JPanel(new BorderLayout());

        ImageIcon img;
        if(bean.getMenu_image() != null) {
            try {
                URL url = new URL(bean.getMenu_image());
                img = new ImageIcon(url);
                Image image = img.getImage().getScaledInstance(200, 150, Image.SCALE_SMOOTH);
                img.setImage(image);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e); //여기서 이미지가 널이면 예외 처리 시킴 그래서 if문 하나 달음
            }

            JLabel imageLabel = new JLabel(img);
            menuItemPanel.add(imageLabel, BorderLayout.CENTER);

            JLabel menuItemPrice = new JLabel(bean.getMenu_price()+"냥");
            menuItemPanel.add(menuItemPrice, BorderLayout.SOUTH);
        }
        return menuItemPanel;
    }

    private void addToCart(String itemName, int itemPrice) {
        if (cartItems.containsKey(itemName)) {
            CartItem cartItem = cartItems.get(itemName);
            cartItem.incrementQuantity();
        } else {
            CartItem newCartItem = new CartItem(itemName, 1, itemPrice);
            cartItems.put(itemName, newCartItem);
        }

        updateTotalCost();
        updateCartPanel();
    }

    private void updateTotalCost() {
        int totalCost = 0;
        for (CartItem cartItem : cartItems.values()) {
            totalCost += cartItem.getTotalPrice();
        }
        totalLabel.setText(String.format("%d", totalCost));
    }

    private void updateCartPanel() {
        JPanel cartItemsPanel = new JPanel();
        cartItemsPanel.setLayout(new BoxLayout(cartItemsPanel, BoxLayout.Y_AXIS));

        for (CartItem cartItem : cartItems.values()) {
            JPanel itemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

            // Create a remove button for each item
            JButton removeButton = new JButton("제거");
            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cartItems.remove(cartItem.getItemName());
                    updateTotalCost();
                    updateCartPanel();
                }
            });

            JLabel itemNameLabel = new JLabel(cartItem.getItemName());

            JButton minusButton = new JButton("-");
            minusButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cartItem.decrementQuantity();
                    updateTotalCost();
                    updateCartPanel();
                }
            });

            JLabel quantityLabel = new JLabel("x" + cartItem.getQuantity());

            JButton plusButton = new JButton("+");
            plusButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cartItem.incrementQuantity();
                    updateTotalCost();
                    updateCartPanel();
                }
            });

            JLabel priceLabel = new JLabel(cartItem.getTotalPrice()+"냥");

            itemPanel.add(removeButton);
            itemPanel.add(itemNameLabel);
            itemPanel.add(minusButton);
            itemPanel.add(quantityLabel);
            itemPanel.add(plusButton);
            itemPanel.add(priceLabel);

            cartItemsPanel.add(itemPanel);
        }

        JPanel cartPanel = (JPanel) getContentPane().getComponent(1);
        cartPanel.remove(1); // Remove old cart items panel
        cartPanel.add(cartItemsPanel, 1); // Add updated cart items panel
        revalidate();
        repaint();
    }

    @Data
    private class CartItem {
        private String itemName;
        private int itemPrice;
        private int quantity;

        public CartItem(String itemName, int initialQuantity, int itemPrice) {
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.quantity = initialQuantity;
        }

        public String getItemName() {
            return itemName;
        }

        public int getQuantity() {
            return quantity;
        }

        public void incrementQuantity() {
            quantity++;
        }

        public void decrementQuantity() {
            if (quantity > 1) {
                quantity--;
            } else if (quantity == 1) {
                quantity--;
                cartItems.remove(itemName);
            }
        }

        public double getTotalPrice() {
            return itemPrice * quantity;
        }
    }
    public static void setMemberBean(MemberBean bean) {
        MenuPan.mbean = bean;
    }
    private void clearCart() {
        cartItems.clear();
        updateTotalCost();
        updateCartPanel();
    }

    public static void setLocalPcBean(LocalPcBean bean) {
        MenuPan.pcbean = bean;
    }

}
