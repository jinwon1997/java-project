package form;

import DB.AdminMgr;
import DB.MemberMgr;
import bean.LocalBean;
import DB.LocalMgr;
import bean.LocalPcBean;
import bean.MemberBean;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.plaf.synth.SynthSpinnerUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class LocalPc extends MFrame implements ActionListener, KeyListener{

    private static MemberBean mbean;
    Vector<LocalBean> localvlist;
    Vector<LocalPcBean> localpcvlist;
    Choice ch;
    JButton searchbtn,selectbtn,mapbtn;
    LocalMgr localmgr;
    MemberMgr membermgr;
    JPanel jp;
    DialogBox err1;
    JTextField jt;
    MyBrowser myBrowser;
    SelectSeat selectseat;
    MyPage page;
    MenuBar bar;
    Menu file;
    LocalPcBean lpbean;

    private static String selectpc;
    private static int selectpcNum;
    ImageIcon img = new ImageIcon("C:\\myeongseung\\Pro\\BTOBProject\\src\\main\\java\\images\\map.jpg");
    Game game;
    MemberBean bean = new MemberBean();
    private JTable table;
    ArrayList<Integer> changedRows = new ArrayList<>();
    public LocalPc() {
        super(700, 500);
        setTitle("Local Pc");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
            }
        });
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        localmgr = new LocalMgr();
        jp = new JPanel();
        localvlist = localmgr.getLocalname();   // 각 구,군의 이름을 가져옴
        ch = new Choice();
        String localname[] = new String[localvlist.size()];
        jp.setBackground(Color.GRAY);
        ch.add("전체조회");
        for (int i = 0; i < localvlist.size(); i++) {   //
            LocalBean localbean = localvlist.get(i);
            localname[i] = localbean.getLocalName();
            ch.add(localname[i]);
        }

        DefaultTableModel model = new DefaultTableModel(new Object[]{"Check","번호",  "피시이름", "주소", "좌석수","전화번호"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> Boolean.class;
                    case 1 -> Integer.class;
                    case 2 -> String.class;
                    case 3 -> String.class;
                    case 4 -> Integer.class;
                    case 5 -> String.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0;
            }

        };
        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e.getColumn() == 0) {
                    boolean isChecked = (boolean) model.getValueAt(e.getFirstRow(), 0);
                    if (isChecked) {
                        for (int i = 0; i < model.getRowCount(); i++) {
                            if (i != e.getFirstRow()) {
                                model.setValueAt(false, i, 0);
                            }
                        }
                    }
                }
            }
        });

        table = new JTable();
        table.setModel(model);


        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(86, 192, 1041, 460);

        ch.select(mbean.getLocalNum());
        jt = new JTextField("", 10);   // 검색창 textfield
        searchbtn = new JButton("검색");
        selectbtn = new JButton("선택");
        mapbtn = new JButton(img);
        mapbtn.setBorder(null);
        mapbtn.setBackground(Color.gray);
        jp.add(ch);
        jp.add(jt);
        jp.add(searchbtn);
        jp.add(selectbtn);
        jp.add(mapbtn);
        searchbtn.addActionListener(this);
        selectbtn.addActionListener(this);
        mapbtn.addActionListener(this);
        add(jp, BorderLayout.NORTH);
        localpcvlist = localmgr.selectLocalPcList(ch.getSelectedIndex(),"*");      // 선택된 지역의 피시방 정보
        //처음 로드 데이터 삽입
        for (int i = 0; i <= localpcvlist.size()-1; i++) {
            LocalPcBean pcbean = localpcvlist.get(i);
            model.addRow(new Object[]{false,pcbean.getLocal_pcNum(), pcbean.getLocal_pcName(), pcbean.getLocal_pcAddress(),pcbean.getLocal_pcQuantity(), pcbean.getLocal_pcPhone()});
        }

        //다음 선택 검색 할때 해줘야함

        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setMaxWidth(50);

        table.getTableHeader().setReorderingAllowed(false);         // 컬럼들 이동 불가
        table.getTableHeader().setResizingAllowed(false);           // 컬럼 크기 조절 불가

        table.setDefaultRenderer(String.class, centerRenderer);
        table.setDefaultRenderer(Integer.class, centerRenderer);
        add(scrollPane);

        bar = new MenuBar();
        file = new Menu("메뉴");
        file.add("내정보");
        file.add("채팅방");
        file.add("로그아웃");
        bar.add(file);
        setMenuBar(bar);
        file.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cmd = e.getActionCommand();
                if(cmd.equals("내정보")) {
                    page.setBean(mbean);
                    page = new MyPage();
                    page.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosing(WindowEvent e) {
                            super.windowClosing(e);
                            page.setVisible(false);
                            page.dispose();
                        }
                    });

                }else if(cmd.equals("채팅방")) {
                    if (game==null) {
                        game.setBean(mbean);
                        game = new Game();
                    }else {
                        game.setVisible(true);
                    }
                }else if(cmd.equals("로그아웃")) {
                    LoginHome lh = new LoginHome();
                    dispose();
                }
            }
        });

        selectbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    boolean isSelected = (boolean) model.getValueAt(row, 0);
                    if (isSelected) {
                        localmgr = new LocalMgr();
                        lpbean = new LocalPcBean();
                        int pcNum = (int) model.getValueAt(row, 1);
                        lpbean = localmgr.selectPcNum(pcNum);
                        selectseat.setMemberBean(mbean);
                        selectseat.setLocalPcBean(lpbean);
                        if(selectseat == null){
                            selectseat = new SelectSeat();
                        } else if (selectseat != null) {
                            selectseat.dispose();
                            localmgr = new LocalMgr();
                            lpbean = new LocalPcBean();
                            pcNum = (int) model.getValueAt(row, 1);
                            lpbean = localmgr.selectPcNum(pcNum);
                            selectseat.setMemberBean(mbean);
                            selectseat.setLocalPcBean(lpbean);
                            selectseat = new SelectSeat();
                        }
                    }
                }
            }
        });

        searchbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setNumRows(0);
                if(ch.getSelectedIndex() == 0){ //부산 전체 구
                    if (jt.getText().trim().length() > 0) { //검색어 O
                        localpcvlist = localmgr.selectAllPc(jt.getText().trim());
                        for (int i = 0; i < localpcvlist.size(); i++) {
                            LocalPcBean localpcbean = localpcvlist.get(i);
                            model.addRow(new Object[]{false,localpcbean.getLocal_pcNum(),
                                    localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                    ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                        }
                    } else if (jt.getText().trim().length() == 0) { //검색어 X
                        localpcvlist = localmgr.selectAllPc("*");
                        for (int i = 0; i <= localpcvlist.size()-1; i++) {
                            LocalPcBean pcbean = localpcvlist.get(i);
                            model.addRow(new Object[]{false,pcbean.getLocal_pcNum(), pcbean.getLocal_pcName(),
                                    pcbean.getLocal_pcAddress()
                                    ,pcbean.getLocal_pcQuantity(), pcbean.getLocal_pcPhone()});
                        }
                    }

                }else{
                    if (jt.getText().trim().length() > 0) {
                        localpcvlist = localmgr.selectFindPc(ch.getSelectedIndex(), jt.getText());
                        for (int i = 0; i < localpcvlist.size(); i++) {
                            LocalPcBean localpcbean = localpcvlist.get(i);
                            model.addRow(new Object[]{false,localpcbean.getLocal_pcNum(), localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                    ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                        }
                    } else if (jt.getText().trim().length() == 0) {
                        localpcvlist = localmgr.selectLocalPcList(ch.getSelectedIndex(),"*");
                        for (int i = 0; i < localpcvlist.size(); i++) {
                            LocalPcBean localpcbean = localpcvlist.get(i);
                            if(localpcbean.getLocal_pcName() != null) {
                                model.addRow(new Object[]{false,localpcbean.getLocal_pcNum(), localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                        ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                            }
                        }
                    }
                    localmgr.selectFindPc(ch.getSelectedIndex()+1,jt.getText().trim());
                }
            }
        });

        ch.addKeyListener(this);
        jt.addKeyListener(this);

        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                if (!changedRows.contains(row)) {
                    changedRows.add(row);
                }
            }
        });

        setResizable(false);
        setVisible(true);
        validate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        membermgr = new MemberMgr();
        localvlist = localmgr.getLocalname();
        String str1;
        String str2 = ch.getSelectedItem().toString();
        if (obj == mapbtn) {
            myBrowser.setBean(mbean);
            myBrowser = new MyBrowser();
        }
    }


    public static void setBean(MemberBean bean) {
        LocalPc.mbean = bean;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            searchbtn.doClick();  // 로그인 버튼 클릭 시뮬레이트

        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}