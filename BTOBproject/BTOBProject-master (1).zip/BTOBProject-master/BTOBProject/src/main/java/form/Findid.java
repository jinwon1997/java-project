package form;

import DB.MemberMgr;
import bean.MemberBean;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Findid extends JFrame implements ActionListener{

    LoginHome lf;
    JLabel lbl1, lbl2;
    JTextField tf1, tf2;
    JButton btn1, btn2;
    DialogBox err1;
    MemberMgr mgr;
    public Findid() {

        setTitle("아이디 찾기");
        setBounds(100, 100, 350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().setBackground(new Color(172, 255, 146));

        tf1 = new JTextField("이름 입력");
        tf1.setBounds(55, 50, 220, 30);
        getContentPane().add(tf1);
        tf1.setColumns(10);

        tf2 = new JTextField("주민번호 입력");
        tf2.setBounds(55, 80, 220, 30);
        getContentPane().add(tf2);
        tf2.setColumns(10);

        btn1 = new JButton("확인");
        btn1.setBounds(55, 110, 220, 30);
        getContentPane().add(btn1);

        btn2 = new JButton("뒤로가기");
        btn2.setBounds(55, 140, 220, 30);
        getContentPane().add(btn2);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
        setResizable(true);
        setVisible(true);
        validate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        mgr = new MemberMgr();
        String name = tf1.getText();
        String social = tf2.getText();
        if (obj == btn1) {
            if (name.equals(mgr.getFindId(name,social).getName())
                    && social.equals(mgr.getFindId(name,social).getSocialNum())) {
                err1 = new DialogBox(this,"아이디는 "
                        + mgr.getFindId(name,social).getUserId()+" 입니다.","알림");
                lf = new LoginHome();
                LoginHome.tf1.setText(mgr.getFindId(name,social).getUserId());
                lf.setLocation(getX(),getY());
                dispose();
            }else {
                err1 = new DialogBox(this, "올바르지 않은 정보입니다.","알림");
            }
        }else if (obj == btn2) {
            lf = new LoginHome();
            lf.setLocation(getX(),getY());
            dispose();
        }
    }

    public static void main(String[] args) {
        new Findid();
    }
}
