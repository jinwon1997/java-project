package form;

import DB.AdminMgr;
import DB.GameMgr;
import DB.MemberMgr;
import bean.GameBean;
import bean.LocalBean;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import bean.MemberBean;
import form.ChatProtocol;

import javax.swing.*;


//채팅방 리스트
public class Game extends MFrame implements ActionListener {

    private static MemberBean mbean;
    Button btn[] = new Button[100];
    Button btn_back = new Button("뒤로가기");
    Panel p1,p2;
    GameMgr mgr;
    Vector<GameBean> vlist;
    LocalPc localPc;
    String[] str = new String[100];
    Socket sock;
    BufferedReader in;
    PrintWriter out;
    String host = "113.198.238.93";
    MemberMgr memberMgr;
    MemberBean bean = new MemberBean();
    ChatClient chatClient;
    AdminMgr adminMgr;
    int j;
    int k;

    public Game() {
        super(300, 400);
        setTitle("채팅방 목록");
        ////////////////////////////////////////////////
        p1 = new Panel();
        p1.setLayout(new GridLayout(12,2));
        mgr = new GameMgr();
        vlist = mgr.getGameList();
        for (int i=0;i<vlist.size();i++){
            if(vlist.equals(null)){
                break;
            }
            GameBean bean = vlist.get(i);
            str[i] = bean.getGameName();
            btn[i] = new Button(str[i]);
            btn[i].addActionListener(this);
            p1.add(btn[i]);
        }
        System.out.println(vlist.size());
        add(BorderLayout.CENTER, p1);
        ////////////////////////////////////////////////
        p2 = new Panel();
        p2.add(btn_back);
        btn_back.addActionListener(this);
        add(BorderLayout.SOUTH, p2);
        ////////////////////////////////////////////////
        validate();
    }

    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        for (int i = 0; i < btn.length; i++) {
            if(obj==btn[i]){
                if(sock==null) {
                    //처음시도
                    ChatProtocol.GAMENAME = str[i];
                    adminMgr = new AdminMgr();
                    connect(adminMgr.selectChat().get(i).getGameNum());
                }else {
                    ChatProtocol.GAMENAME = str[i];
                    connect(adminMgr.selectChat().get(i).getGameNum());
                }
                String chatid = mbean.getUserId();
                String msg = ChatProtocol.ID + ChatProtocol.MODE + chatid + ";" + mbean.getUserPassword();
                System.out.println("msg : " + msg);
                out.println(ChatProtocol.ID + ChatProtocol.MODE + chatid + ";" + mbean.getUserPassword());
                try {
                    String line = in.readLine();
                    int idx = line.indexOf(ChatProtocol.MODE);
                    String cmd = line.substring(0, idx);
                    System.out.println(chatid);
                    if(cmd.equals(ChatProtocol.ID)) {
                        chatClient.setBean(mbean);
                        new ChatClient(in, out, chatid);
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        if(obj==btn_back) {
            dispose();
        }
    }

    public void connect(int port) {
        try {
            sock = new Socket(host, port);
            in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            out = new PrintWriter(sock.getOutputStream(), true/* auto flush */);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }// --connect

    public static void setBean(MemberBean mbean) {
        Game.mbean = mbean;
    }

    public static void main(String[] args) {
        new Game();
    }
}