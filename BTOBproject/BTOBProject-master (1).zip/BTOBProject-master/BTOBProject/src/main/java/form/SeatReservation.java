package form;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class SeatReservation {

    JFrame frame;
    JButton btnNewButton[] = new JButton[80];
    //각 예약석의 버튼
    JButton btn1 = new JButton();
    //뒤로가기 버튼

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SeatReservation window = new SeatReservation();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public SeatReservation() {
        initialize();
    }


    class ButtonListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Object obj = e.getSource();
            for(int i = 0; i< btnNewButton.length; i++){
                if(obj==btnNewButton[i]){
                    if(JOptionPane.showConfirmDialog(null, (i+1)+"번 자리를 예약하시겠습니까?", "자리 예약", JOptionPane.YES_NO_OPTION)!=JOptionPane.NO_OPTION) {
//                        System.out.println("예약 페이지로...");
                        frame.dispose();
                        Game game = new Game();
                    } else {
                        System.out.println("취소됨");
                    }
                }
            }
            if(obj==btn1){
//                System.out.println("뒤로가기");
                frame.dispose();
                LocalPc localPc = new LocalPc();
            }
        }

    }

    //이 밑의 코드들은 전부 버튼 배치해놓고 actionPerformed 넣은 거라 신경 안 쓰셔도 됩니다.
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 979, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(26, 40, 905, 450);
        frame.getContentPane().add(panel);
        panel.setLayout(null);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(0, 0, 905, 56);
        panel.add(panel_1);
        panel_1.setLayout(null);

        JLabel lblNewLabel = new JLabel("PC\uBC29 \uC88C\uC11D \uC608\uC57D\uD558\uAE30");
        lblNewLabel.setBounds(12, 10, 139, 36);
        panel_1.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("\uC88C\uC11D \uC120\uD0DD\uCC3D");
        lblNewLabel_1.setBounds(382, 21, 115, 15);
        panel_1.add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("\uCD9C\uC785\uBB38");
        lblNewLabel_2.setBounds(848, 230, 57, 39);
        panel.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("\uB0A8\uC790\uD654\uC7A5\uC2E4");
        lblNewLabel_3.setBounds(10, 66, 78, 15);
        panel.add(lblNewLabel_3);

        JLabel lblNewLabel_3_1 = new JLabel("\uC5EC\uC790\uD654\uC7A5\uC2E4");
        lblNewLabel_3_1.setBounds(100, 66, 78, 15);
        panel.add(lblNewLabel_3_1);

        JLabel lblNewLabel_3_1_1 = new JLabel("\uD761\uC5F0\uC2E4");
        lblNewLabel_3_1_1.setBounds(0, 214, 34, 68);
        panel.add(lblNewLabel_3_1_1);

        int x=0;
        int y=0;
        for(int i = 0; i<btnNewButton.length; i+=20){
            for(int j = 0; j<20; j+=2){
                btnNewButton[i+j] = new JButton("'"+(i+j+1)+"'");
                btnNewButton[i+j].setBounds(46+x, 92+y, 80, 23);
                btnNewButton[i+j].addActionListener(new ButtonListener());
                panel.add(btnNewButton[i+j]);

                btnNewButton[i+j+1] = new JButton("'"+(i+j+2)+"'");
                btnNewButton[i+j+1].setBounds(122+x, 92+y, 80, 23);
                btnNewButton[i+j+1].addActionListener(new ButtonListener());
                panel.add(btnNewButton[i+j+1]);

                y+=30;
            }
            x+=200;
            y=0;
        }

        btn1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
        btn1.setBounds(0, 427, 97, 23);
        btn1.addActionListener(new ButtonListener());
        panel.add(btn1);
    }
}
