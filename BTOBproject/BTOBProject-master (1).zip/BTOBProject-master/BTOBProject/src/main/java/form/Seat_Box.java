package form;

import DB.PcSeatMgr;
import DB.ReservationMgr;
import bean.*;
import com.mysql.cj.protocol.a.LocalDateValueEncoder;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

public class Seat_Box extends JFrame {

    ReservationMgr mgr;
    Vector<ReservationBean> Revlist;
    JLabel user_id2;
    Calendar calendar;
    private static MemberBean mbean;
    private static LocalPcBean pcbean;
    private static PcSeatBean pcseatbean;
    ImageIcon ReImage = new ImageIcon("C:\\BTOBProject_1\\src\\main\\java\\images\\ari.png");
    Set<Integer> reservedHours = new HashSet<>();

    // 좌석 번호와 예약 시간을 저장하는 Map
    private Map<Integer, Date> seatReservations = new HashMap<>();

    public Seat_Box() {
        super();
        ReservationBean bean = new ReservationBean();
        mgr = new ReservationMgr();
        setTitle("좌석 예약하기");
        setPreferredSize(new Dimension(500, 600));

        JPanel Rpanel = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(ReImage.getImage(), 0, 0, null);
                setOpaque(false);
            }
        };
        Rpanel.setLayout(null);
        Rpanel.setBounds(0, 0, 500, 600);
        add(Rpanel);

        Revlist = mgr.getReservationList(pcseatbean.getSeat_Num());

        String seatid[] = new String[Revlist.size()];

        setLayout(null);

        JLabel user_id = new JLabel("아이디 :");
        user_id.setBounds(50, 20, 70, 20);

        user_id2 = new JLabel(mbean.getUserId());
        user_id2.setBounds(120, 20, 100, 20);

        JLabel user_charge = new JLabel("좌석 번호 :");
        user_charge.setBounds(45, 70, 80, 20);

        JLabel user_charge2 = new JLabel(String.valueOf(pcseatbean.getSeat_Num()));
        user_charge2.setBounds(125, 70, 100, 20);

        JLabel reserve_time = new JLabel("예약할 시간 :");
        reserve_time.setBounds(40, 120, 80, 20);

        // 예약된 시간대를 저장할 Set 초기화
        Set<Integer> reservedHours = new HashSet<>();

        for (ReservationBean reservation : Revlist) {
            Timestamp RTime = reservation.getReservation_Time();
            Timestamp endTime = reservation.getEnd_Time();
            Date now = Calendar.getInstance().getTime();

            if (RTime.getDate() >= now.getDate()) {
                int RHour = RTime.getHours();
                int endHour = endTime.getHours();

                for (int i = RHour; i <= endHour; i++) {
                    reservedHours.add(i);
                }
            }
        }

        Choice TimeChoice = new Choice();

//         모든 시간대(0~23)를 확인하여 예약된 시간대를 제외하고 TimeChoice에 추가
        for (int i = 0; i <= 23; i++) {
            if (!reservedHours.contains(i)) {
                TimeChoice.add(i + ":00");
            }
        }

        TimeChoice.setBounds(125, 120, 100, 20);

        Label resultLabel = new Label();
        resultLabel.setBounds(240, 120, 110, 20);
        final int[] t1 = new int[1];

        String startTime = String.valueOf(mgr.getReservationList(pcseatbean.getSeat_Num())
                .get(mgr.getReservationList(pcseatbean.getSeat_Num()).size() - 1)
                .getReservation_Time());

        String truncatedEndTime = startTime.substring(11, 13);
        int istarttime = Integer.parseInt(truncatedEndTime);
        System.out.println(truncatedEndTime);
        Choice TimeChoice2 = new Choice();
        TimeChoice.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selectedTime = TimeChoice.getSelectedItem();
                resultLabel.setText("선택한 시간: " + selectedTime);
                t1[0] = TimeChoice.getSelectedIndex();
                System.out.println(t1[0]);
                int cnt = 24;
                boolean flag = true;
                System.out.println(t1[0]);
                while(flag){
                    cnt--;
                    if(t1[0] + cnt == istarttime){
                        for(int i=1; i<cnt+1;i++){
                            System.out.println(i);
                            TimeChoice2.add(i + ":00");
                        }
                        flag = false;
                    }

                }
            }
        });

        JLabel end_time = new JLabel("사용할 시간 :");
        end_time.setBounds(40, 170, 80, 20);

//        for (ReservationBean reservation : Revlist) {
//            Timestamp RTime2 = reservation.getReservation_Time();
//            Timestamp endTime2 = reservation.getEnd_Time();
//            Date now = Calendar.getInstance().getTime();
//
//            if (RTime2.getDate() >= now.getDate()) {
//                int RHour2 = RTime2.getHours();
//                int endHour2 = endTime2.getHours();
//
//                for (int i = RHour2; i <= endHour2; i++) {
//                    reservedHours.add(i);
//                }
//            }
//        }
        //예약이 된 시간 까지 사용이 가능하게끔만 리스트로 띄우면 된다.

        //choice2 ==> choice1 : 시작시간 : 05:00 사용할 시간 : 3 05~08
//        for (int i = 1; i < 25; i++) {
//            if(!reservedHours.contains(i)) {
//                TimeChoice2.add(i + ":00");
//            }
//        }
        //int t1 = TimeChoice.getSelectedIndex();


        //while 문을 써가지고 5->9까지 예약
        //choice를 3을 눌렀다 그러면
        //int cnt + choice.getselectedIndex+1 == i
        //

        TimeChoice2.setBounds(125, 170, 100, 20);

        Label resultLabel2 = new Label();
        resultLabel2.setBounds(240, 170, 110, 20);
        TimeChoice2.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selectedTime2 = TimeChoice2.getSelectedItem();
                resultLabel2.setText("사용할 시간: " + selectedTime2);
            }
        });


        JTextArea Precautions = new JTextArea("주의 사항:현재시간 이후의 예약은 당일 예약이며\n"+"현재시간 이전의 예약은 다음날 예약시간으로 됩니다!\n" +
                "만일 예약하고 싶은 시간이 안나온다면\n"+"그 자리에는 이미 예약이 되어있다는 것입니다.");
        Font font = new Font("SanSerif", Font.BOLD, 17);
        Precautions.setFont(font);
        Color PinkColor = new Color(0xFBEFFB);
        Precautions.setBackground(PinkColor);
        Precautions.setForeground(Color.DARK_GRAY);
        Precautions.setBounds(20,370,420,100);

        JButton RButton = new JButton("예약하기");
        RButton.setBounds(200, 500, 100, 50);
        RButton.setBackground(Color.PINK);
        RButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        RButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object obj = e.getSource();
                if (RButton == obj) {
                    String selectedTime = TimeChoice.getSelectedItem();
                    String selectedTime2 = TimeChoice2.getSelectedItem();

                    // selectedTime과 selectedTime2를 Date 형식으로 변환
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                    Date time1 = null;
                    Date time2 = null;
                    try {
                        time1 = sdf.parse(selectedTime);
                        time2 = sdf.parse(selectedTime2);
                    } catch (ParseException ex) {
                        ex.printStackTrace();
                        return; // 변환 실패 시 종료
                    }

                    // calendar 객체 초기화
                    calendar = Calendar.getInstance();

                    int additionalHours = Integer.parseInt(selectedTime2.split(":")[0]);

                    // 현재 시간을 설정된 기준 시간으로 설정
                    calendar.set(Calendar.HOUR_OF_DAY, time1.getHours());
                    calendar.set(Calendar.MINUTE, time1.getMinutes());
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);

                    calendar.add(Calendar.HOUR_OF_DAY, additionalHours);

                    Date now = Calendar.getInstance().getTime();

                    // 선택한 시간이 현재 시간보다 이전이면 날짜를 하루 추가하여 내일의 같은 시간으로 설정
                    if (now.after(calendar.getTime())) {
                        calendar.add(Calendar.DAY_OF_MONTH, 1);
                    }

                    // time1을 calendar에 설정
                    calendar.set(Calendar.HOUR_OF_DAY, time1.getHours());
                    calendar.set(Calendar.MINUTE, time1.getMinutes());
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);

                    Date startTime = calendar.getTime();

                    // time2를 더함
                    calendar.add(Calendar.HOUR_OF_DAY, additionalHours);

                    Date endTime = calendar.getTime();

                    // 예약한 좌석 번호 가져오기
                    int seatNum = pcseatbean.getSeat_Num();

                    // 좌석 번호에 해당하는 예약 시간 업데이트
                    seatReservations.put(seatNum, startTime);

                    Timestamp nowTimestamp = new Timestamp(now.getTime());
                    Timestamp startTimeStamp = new Timestamp(startTime.getTime());
                    Timestamp endTimeStamp = new Timestamp(endTime.getTime());

                    bean.setConnecting_Time(nowTimestamp);
                    bean.setReservation_Time(startTimeStamp);
                    bean.setStart_Time(startTimeStamp); // 시작 시간
                    bean.setEnd_Time(endTimeStamp); // 종료 시간
                    bean.setUserId(mbean.getUserId());
                    bean.setSeat_Num(pcseatbean.getSeat_Num());

                    mgr.insertReservation(bean);

                    JOptionPane.showMessageDialog(null, "예약이 완료되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        Rpanel.add(RButton);
        Rpanel.add(user_id);
        Rpanel.add(user_id2);
        Rpanel.add(user_charge);
        Rpanel.add(user_charge2);
        Rpanel.add(reserve_time);
        Rpanel.add(TimeChoice);
        Rpanel.add(resultLabel);
        Rpanel.add(end_time);
        Rpanel.add(TimeChoice2);
        Rpanel.add(resultLabel2);
        Rpanel.add(Precautions);
        pack();
        setVisible(true);
        validate();
    }

    public static void setMemberBean(MemberBean bean) {
        Seat_Box.mbean = bean;
    } //Seat_Box에 bean 추가
    public static void setPcBean(LocalPcBean bean) {Seat_Box.pcbean = bean;}
    public static void setPcSeatBean(PcSeatBean bean){Seat_Box.pcseatbean = bean;
    }
}