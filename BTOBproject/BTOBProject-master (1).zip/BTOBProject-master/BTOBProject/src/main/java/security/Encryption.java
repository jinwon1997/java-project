package security;

import DB.MemberMgr;

import java.security.MessageDigest;

public class Encryption {

    public static String SHA256(String pw) throws Exception{
        StringBuffer sbuf = new StringBuffer();

        MessageDigest mDigest = MessageDigest.getInstance("SHA-256");
        mDigest.update(pw.getBytes());

        byte[] msgStr = mDigest.digest() ;

        for(int i=0; i < msgStr.length; i++){
            byte tmpStrByte = msgStr[i];
            String tmpEncTxt = Integer.toString((tmpStrByte & 0xff) + 0x100, 16).substring(1);

            sbuf.append(tmpEncTxt) ;
        }

        return sbuf.toString();
    }
    public static void main(String[] args) throws Exception{
        MemberMgr mgr = new MemberMgr();
        mgr.getFindPassword("권명승","990115-1234567","aaa").getUserPassword();
        String pw = mgr.getFindPassword("권명승","990115-1234567","aaa").getUserPassword();
        System.out.println("pw : " + pw);
        System.out.println("SHA256 : " + SHA256(pw));

    }
}
