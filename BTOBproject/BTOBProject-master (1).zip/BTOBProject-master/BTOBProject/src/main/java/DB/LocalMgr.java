package DB;


import bean.LocalBean;
import bean.LocalPcBean;
import bean.MemberBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Vector;
import java.util.Map;

public class LocalMgr {

    static LocalMgr lmg = new LocalMgr();
    private DBConnectionMgr pool;

    public LocalMgr() {
        pool = DBConnectionMgr.getInstance();
    }

    // 리스트
    public Vector<LocalBean> getLocalname() {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<LocalBean> vlist = new Vector<LocalBean>();
        try {
            con = pool.getConnection();
            sql = "select * from local";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                LocalBean bean = new LocalBean();
                bean.setLocalNum(rs.getInt("local_num"));
                bean.setLocalName(rs.getString("local_name"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    // 지역별 pc방 리스트
    public Vector<LocalPcBean> selectLocalPcList(int local_num,String local_pc_info) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<LocalPcBean> vlist = new Vector<LocalPcBean>();
        try {
            con = pool.getConnection();
            if (local_pc_info.equals("*")) {
                sql = "SELECT p.* from local AS l LEFT OUTER JOIN local_pc as p ON l.local_num = p.local_num WHERE l.local_num = ? ";
                pstmt = con.prepareStatement(sql);
                pstmt.setInt(1,local_num);
            }
            else {
                sql = "SELECT p.* from local AS l LEFT OUTER JOIN local_pc as p ON l.local_num = p.local_num WHERE l.local_num = ? and (local_pcAddress like ? or local_pcName like ?)";
                pstmt = con.prepareStatement(sql);
                pstmt.setInt(1,local_num);
                pstmt.setString(2, "%" + local_pc_info + "%");
                pstmt.setString(3, "%" + local_pc_info + "%");
            }
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                LocalPcBean bean = new LocalPcBean();
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setLocal_num(rs.getInt("local_num"));
                bean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setLocal_pcAddress(rs.getString("local_pcAddress"));
                bean.setLocal_pcPhone(rs.getString("local_pcPhone"));
                bean.setLocal_pcQuantity(rs.getInt("local_pcQuantity"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public Vector<LocalPcBean> selectAllPc(String name) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<LocalPcBean> vlist = new Vector<>();
        try {
            con = pool.getConnection();
            if (name.equals("*")) {
                sql = "select * from local_pc";
                pstmt = con.prepareStatement(sql);
            } else if (!name.equals("*")) {
                sql = "select * from local_pc where local_pcName like ? or local_pcAddress like ?";
                pstmt = con.prepareStatement(sql);
                pstmt.setString(1,"%" + name + "%");
                pstmt.setString(2,"%" + name + "%");
            }
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                LocalPcBean bean = new LocalPcBean();
                bean.setLocal_num(rs.getInt("local_num"));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setLocal_pcAddress(rs.getString("local_pcAddress"));
                bean.setLocal_pcQuantity(rs.getInt("local_pcQuantity"));
                bean.setLocal_pcPhone(rs.getString("local_pcPhone"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public Vector<LocalPcBean> selectFindPc(int num, String st) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<LocalPcBean> vlist = new Vector<>();
        try {
            con = pool.getConnection();
            sql = "select * from local_pc where local_num = ?  and (local_pcAddress like ? or local_pcName like ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.setString(2, "%" + st + "%");
            pstmt.setString(3, "%" + st + "%");
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                LocalPcBean bean = new LocalPcBean();
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setLocal_num(rs.getInt("local_num"));
                bean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setLocal_pcAddress(rs.getString("local_pcAddress"));
                bean.setLocal_pcQuantity(rs.getInt("local_pcQuantity"));
                bean.setLocal_pcPhone(rs.getString("local_pcPhone"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public Vector<LocalBean> selectFindlocal(String st) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<LocalBean> vlist = new Vector<LocalBean>();
        try {
            con = pool.getConnection();
            sql = "select local_num from local where local_name = ?  ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, st);
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                LocalBean bean = new LocalBean();
                bean.setLocalNum(rs.getInt("local_num"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public LocalPcBean selectPcname(String pcname) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        LocalPcBean bean = new LocalPcBean();
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM local_pc WHERE local_pcName = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, pcname);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setLocal_pcPhone(rs.getString("local_pcPhone"));
                bean.setLocal_pcQuantity(rs.getInt("local_pcQuantity"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        return bean;
    }

    public LocalPcBean selectPcNum(int pcNum) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        LocalPcBean bean = new LocalPcBean();
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM local_pc WHERE local_pcNum = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, pcNum);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setLocal_pcPhone(rs.getString("local_pcPhone"));
                bean.setLocal_pcQuantity(rs.getInt("local_pcQuantity"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        return bean;
    }

    public static void main(String[] args) {
        LocalMgr mgr = new LocalMgr();
        System.out.println(mgr.selectAllPc("*").size());
        System.out.println(mgr.selectFindPc(8,"아이러브"));
    }

}