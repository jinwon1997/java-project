package DB;

import bean.PcSeatBean;
import bean.ReservationBean;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class PcSeatMgr {

    private DBConnectionMgr pool;

    public PcSeatMgr(){pool = DBConnectionMgr.getInstance();}

    public Vector<PcSeatBean> getPcSeatList(){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<PcSeatBean> vlist = new Vector<PcSeatBean>();
        try {
            con = pool.getConnection();
            sql = "SELECT pc_seat.seat_num, seat_reservation.user_id, \n" +
                    "seat_reservation.reservation_time, seat_reservation.start_time, \n" +
                    "seat_reservation.end_time,pc_seat.local_pcNum, pc_seat.pc_statement\n" +
                    "FROM seat_reservation\n" +
                    "LEFT OUTER JOIN pc_seat ON seat_reservation.seat_num = pc_seat.seat_num" +
                    "WHERE DATE(seat_reservation.reservation_time) = DATE(NOW());";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                PcSeatBean bean = new PcSeatBean();
                ReservationBean Rbean = new ReservationBean();
                bean.setSeat_Num(rs.getInt("seat_num"));
                bean.setUserId(rs.getString("user_id"));
                Rbean.setReservation_Time(Timestamp.valueOf(rs.getString("reservation_time")));
                Rbean.setStart_Time(Timestamp.valueOf(rs.getString("start_time")));
                Rbean.setEnd_Time(Timestamp.valueOf(rs.getString("end_time")));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setPc_Statement(rs.getInt("pc_statement"));
                bean.setReservation(Rbean);
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public boolean insertReservation(ReservationBean Rbean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "INSERT INTO seat_reservation VALUES(0, ?,?,NOW(),?,?,?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, Rbean.getSeat_Num());
            pstmt.setString(2,Rbean.getUserId());
            pstmt.setString(3, String.valueOf(Rbean.getReservation_Time()));
            pstmt.setString(4, String.valueOf(Rbean.getStart_Time()));
            pstmt.setString(5, String.valueOf(Rbean.getEnd_Time()));
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    public Vector<PcSeatBean> getTmrPcSeatList(){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<PcSeatBean> vlist2 = new Vector<PcSeatBean>();
        try {
            con = pool.getConnection();
            sql = "SELECT pc_seat.seat_num, seat_reservation.user_id, \n" +
                    "seat_reservation.reservation_time, seat_reservation.start_time, \n" +
                    "seat_reservation.end_time,pc_seat.local_pcNum, pc_seat.pc_statement\n" +
                    "FROM seat_reservation\n" +
                    "LEFT OUTER JOIN pc_seat ON seat_reservation.seat_num = pc_seat.seat_num WHERE DATE(seat_reservation.reservation_time) > DATE(NOW());";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                PcSeatBean bean = new PcSeatBean();
                ReservationBean Rbean = new ReservationBean();
                bean.setSeat_Num(rs.getInt("seat_num"));
                bean.setUserId(rs.getString("user_id"));
                Rbean.setReservation_Time(Timestamp.valueOf(rs.getString("reservation_time")));
                Rbean.setStart_Time(Timestamp.valueOf(rs.getString("start_time")));
                Rbean.setEnd_Time(Timestamp.valueOf(rs.getString("end_time")));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setPc_Statement(rs.getInt("pc_statement"));
                bean.setReservation(Rbean);
                vlist2.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist2;
    }

    public Vector<PcSeatBean> getPcSeatNumList(int snum){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<PcSeatBean> vlist3 = new Vector<PcSeatBean>();
        try {
            con = pool.getConnection();
            sql = "SELECT pc_seat.seat_num, seat_reservation.user_id, \n" +
                    "seat_reservation.reservation_time, seat_reservation.start_time, \n" +
                    "seat_reservation.end_time,pc_seat.local_pcNum, pc_seat.pc_statement\n" +
                    "FROM seat_reservation\n" +
                    "LEFT OUTER JOIN pc_seat ON seat_reservation.seat_num = pc_seat.seat_num" +
                    "WHERE pc_seat.seat_num = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,snum);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                PcSeatBean bean = new PcSeatBean();
                ReservationBean Rbean = new ReservationBean();
                bean.setSeat_Num(rs.getInt("seat_num"));
                bean.setUserId(rs.getString("user_id"));
                Rbean.setReservation_Time(Timestamp.valueOf(rs.getString("reservation_time")));
                Rbean.setStart_Time(Timestamp.valueOf(rs.getString("start_time")));
                Rbean.setEnd_Time(Timestamp.valueOf(rs.getString("end_time")));
                bean.setLocal_pcNum(rs.getInt("local_pcNum"));
                bean.setPc_Statement(rs.getInt("pc_statement"));
                bean.setReservation(Rbean);
                vlist3.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist3;
    }


    public static void main(String[] args) {
        PcSeatMgr mgr = new PcSeatMgr();

    }
}
