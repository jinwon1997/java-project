package DB;

import bean.ChatBean;
import bean.GameBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

//import member.DBConnectionMgr;

public class ChatMgr {

    private DBConnectionMgr pool;

    public ChatMgr() {
        pool = DBConnectionMgr.getInstance();
    }

    //로그인
    public boolean loginChk(String id, String pwd) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "SELECT COUNT(user_id) FROM user_mst WHERE user_id = ? AND user_password = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, pwd);
            rs = pstmt.executeQuery();
            if(rs.next()&&rs.getInt(1)==1){
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return flag;
    }

    //Message Insert
    public void insertMsg(ChatBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
//			sql = "insert tblMessage (fid, tid, message) values(?,?,?)";
            sql = "insert pc_message values (null,?,?,?,now())";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, bean.getFid());
            pstmt.setString(2, bean.getTid());
            pstmt.setString(3, bean.getMsg());
            int cnt = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }

    //Message List
    public Vector<ChatBean> getMsgList(String id){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<ChatBean> vlist = new Vector<ChatBean>();
        try {
            con = pool.getConnection();
            sql = "select * from pc_message where fid = ? or tid = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, id);
            rs = pstmt.executeQuery();
            while(rs.next()) {
                ChatBean bean = new ChatBean();
                bean.setNo(rs.getInt(1));
                bean.setFid(rs.getString(2));
                bean.setTid(rs.getString(3));
                bean.setMsg(rs.getString(4));
                bean.setMdate(rs.getString(5));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    //Message Get : select * from tblMessage no = ?
    public ChatBean getMsg(int no/*pk*/) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        ChatBean bean = new ChatBean();
        try {
            con = pool.getConnection();
            sql = "select * from pc_message no = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, no);
            rs = pstmt.executeQuery();
            if(rs.next()) {
                bean.setNo(rs.getInt(1));
                bean.setFid(rs.getString(2));
                bean.setTid(rs.getString(3));
                bean.setMsg(rs.getString(4));
                bean.setMdate(rs.getString(5));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return bean;
    }
    public Vector<GameBean> getChatList(){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<GameBean> vlist = new Vector<GameBean>(); //위치 중요!
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM game";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                GameBean bean = new GameBean();
                bean.setGameNum(rs.getInt("game_num"));
                bean.setGameName(rs.getString("game_name"));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(vlist.size());
        return vlist;
    }
}
