package DB;

import bean.MenuBean;
import bean.ReservationBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.Timestamp;

public class ReservationMgr {

    private DBConnectionMgr pool;

    public ReservationMgr(){pool = DBConnectionMgr.getInstance();}
    public Vector<ReservationBean> getReservationList(int snum){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<ReservationBean> vlist = new Vector<ReservationBean>();
        try {
            con = pool.getConnection();
            sql = "SELECT seat_num , user_id , connecting_time , reservation_time , start_time , end_time FROM seat_reservation WHERE seat_reservation.seat_num = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,snum);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                ReservationBean bean = new ReservationBean();
                bean.setSeat_Num(rs.getInt("seat_num"));
                bean.setUserId(rs.getString("user_id"));
                bean.setConnecting_Time(Timestamp.valueOf(rs.getString("connecting_time")));
                bean.setReservation_Time(Timestamp.valueOf(rs.getString("reservation_time")));
                bean.setEnd_Time(Timestamp.valueOf(rs.getString("end_time")));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }



        return vlist;
    }

    public void insertReservation(ReservationBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "INSERT INTO seat_reservation (seat_num, user_id, connecting_time, reservation_time, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,bean.getSeat_Num());
            pstmt.setString(2, bean.getUserId());
            pstmt.setString(3, bean.getConnecting_Time().toString());
            pstmt.setString(4, bean.getReservation_Time().toString());
            pstmt.setString(5, bean.getStart_Time().toString());
            pstmt.setString(6, bean.getEnd_Time().toString());
            pstmt.executeUpdate(); // insert 실행
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }

    public static void main(String[] args) {
        ReservationMgr mgr = new ReservationMgr();
        //System.out.println(mgr.getReservationList());
    }

    public void insertReservation(String userId) {
    }
}
