package DB;

import bean.MemberBean;
import bean.ZipcodeBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import static security.Encryption.SHA256;

public class MemberMgr {

    private DBConnectionMgr pool;

    public MemberMgr() {
        pool = DBConnectionMgr.getInstance();
    }

    // 유저리스트
    public MemberBean getUserIdList(String id) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        MemberBean bean = new MemberBean();
        try {
            con = pool.getConnection();
            sql = "select user_id from user_mst where user_id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1,id);
            rs = pstmt.executeQuery();
            if(rs.next()) {
                bean.setUserId(rs.getString("user_id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return bean;
    }

    //회원가입
    public boolean insertMember(MemberBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "insert user_mst ()values(?,?,?,?,?,?,?,0,?,0,0,now(),NULL,0)";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, bean.getUserId());
            pstmt.setString(2, bean.getUserPassword());
            pstmt.setString(3, bean.getName());
            pstmt.setInt(4, bean.getLocalNum());
            pstmt.setString(5, bean.getAddress());
            pstmt.setString(6, bean.getPhone());
            pstmt.setInt(7, bean.getGender());
            pstmt.setString(8, bean.getSocialNum());
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //유저 정보
    public MemberBean getUserInfo(MemberBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM user_mst WHERE user_id = ? AND user_password=?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, bean.getUserId());
            pstmt.setString(2, bean.getUserPassword());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUserId(rs.getString("user_id"));
                bean.setUserPassword(rs.getString("user_password"));
                bean.setLocalNum(rs.getInt("local_num"));
                bean.setName(rs.getString("user_name"));
                bean.setAddress(rs.getString("user_address"));
                bean.setPhone(rs.getString("user_phone"));
                bean.setUserCharge(rs.getInt("user_charge"));
                bean.setUserState(rs.getInt("user_state"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        //System.out.println(bean.toString());
        return bean;
    }

    public MemberBean mapUserInfo(String user_id) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        MemberBean bean = new MemberBean();
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM user_mst WHERE user_id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, user_id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUserId(rs.getString("user_id"));
                bean.setUserPassword(rs.getString("user_password"));
                bean.setLocalNum(rs.getInt("local_num"));
                bean.setName(rs.getString("user_name"));
                bean.setUserCharge(rs.getInt("user_charge"));
                bean.setUserState(rs.getInt("user_state"));
                bean.setAddress(rs.getString("user_address"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        //System.out.println(bean.toString());
        return bean;
    }

    //
    public MemberBean getIdPw(String id, String pw) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        MemberBean bean = new MemberBean();
        try {
            con = pool.getConnection();
            sql = "SELECT user_id, user_password, user_authority FROM user_mst WHERE user_id = ? AND user_password=?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, pw);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUserId(rs.getString("user_id"));
                bean.setUserPassword(rs.getString("user_password"));
                bean.setUserAuthority(rs.getInt("user_authority"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return bean;
    }

    //아이디 찾기
    public MemberBean getFindId(String name, String socialnum) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        MemberBean bean = new MemberBean();
        try {
            con = pool.getConnection();
            sql = "SELECT user_id, user_name, user_socialnum FROM user_mst WHERE user_name = ? AND user_socialnum = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, socialnum);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUserId(rs.getString("user_id"));
                bean.setName(rs.getString("user_name"));
                bean.setSocialNum(rs.getString("user_socialnum"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        return bean;
    }

    //비밀번호 찾기
    public MemberBean getFindPassword(String name, String socialnum, String id) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        MemberBean bean = new MemberBean();
        try {
            con = pool.getConnection();
            sql = "SELECT user_name, user_socialnum, user_id,user_password FROM user_mst WHERE user_name = ? AND user_socialnum = ? AND user_id = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, socialnum);
            pstmt.setString(3,id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUserId(rs.getString("user_id"));
                bean.setName(rs.getString("user_name"));
                bean.setSocialNum(rs.getString("user_socialnum"));
                bean.setUserPassword(rs.getString("user_password"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(bean.getUserId() + " : " + bean.getUserPassword());  // 실행되는지 확인용
        return bean;
    }
    
    //포인트 업데이트
    public boolean updateCharge(MemberBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "update user_mst set user_charge = ? where user_id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,bean.getUserCharge());
            pstmt.setString(2, bean.getUserId());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //비밀번호 업데이트
    public boolean updatePassword(MemberBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "update user_mst set user_password = ? where user_name = ? and user_socialnum = ? and user_id = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, SHA256(bean.getUserPassword()));
            pstmt.setString(2, bean.getName());
            pstmt.setString(3, bean.getSocialNum());
            pstmt.setString(4, bean.getUserId());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }
    
    //유저 정보 업데이트
    public boolean updateUser(MemberBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "UPDATE user_mst \n" +
                    "SET local_num = ?, user_address = ?, user_phone = ? WHERE user_id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, bean.getLocalNum());
            pstmt.setString(2, bean.getAddress());
            pstmt.setString(3,bean.getPhone());
            pstmt.setString(4, bean.getUserId());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    // 삭제
    public void deleteMember(int num) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "delete from tblMember where num = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }
    // 주소 검색
    // return을 던졌는데 몇개가 들어올지 모를 경우 vector 사용(배열의 경우 크기('몇개인지')를 알아야함 ),그리고 Vector는 동기화가 가능
    public Vector<ZipcodeBean> searchZipcode(String area3) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<ZipcodeBean> vlist = new Vector<ZipcodeBean>();
        try {
            con = pool.getConnection();
            sql = "select * from tblZipcode where area3 like ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + area3 + "%");            //'%강남대로%'
            rs = pstmt.executeQuery();
            while(rs.next()) {
                ZipcodeBean bean = new ZipcodeBean();
                bean.setZipcode(rs.getString(1));
                bean.setArea1(rs.getString(2));
                bean.setArea2(rs.getString(3));
                bean.setArea3(rs.getString(4));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    public static void main(String[] args) {
        MemberMgr mgr = new MemberMgr();
        MemberBean bean = new MemberBean();
        bean.setUserCharge(50000);
        bean.setUserId("aaa");
        mgr.updateCharge(bean);

    }
}
