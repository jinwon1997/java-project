package DB;

import bean.LocalPcBean;
import bean.MemberBean;
import bean.MenuBean;
import bean.MenuPocketBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Vector;

public class MenuMgr {

    private DBConnectionMgr pool;

    public MenuMgr() {
        pool = DBConnectionMgr.getInstance();
    }
    public Vector<MenuBean> getMenuList(){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<MenuBean> vlist = new Vector<MenuBean>(); //위치 중요!
        try {
            con = pool.getConnection();
            sql = "SELECT * FROM pc_menu";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                MenuBean bean = new MenuBean();
                bean.setMenu_num(rs.getInt("menu_num"));
                bean.setMenu_image(rs.getString("menu_image"));
                bean.setMenu_name(rs.getString("menu_name"));
                bean.setMenu_price(rs.getInt("menu_price"));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(vlist.size());
        return vlist;
    }

    public Vector<MenuPocketBean> getUserPaymentList(String user_id, Timestamp time){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<MenuPocketBean> vlist = new Vector<MenuPocketBean>(); //위치 중요!
        try {
            con = pool.getConnection();
            sql = "SELECT mp.menu_name, mp.menu_count, mp.menu_price, mp.user_id, mp.pocket_time ,lp.local_pcName\n" +
                    "FROM menu_pocket mp\n" +
                    "LEFT OUTER JOIN local_pc lp\n" +
                    "\tON mp.local_pcNum = lp.local_pcNum \n" +
                    "where user_id = ? and pocket_time = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, user_id);
            pstmt.setTimestamp(2, time);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                MenuPocketBean bean = new MenuPocketBean();
                LocalPcBean lbean = new LocalPcBean();
                lbean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setMenuName(rs.getString("menu_name"));
                bean.setMenuCount(rs.getInt("menu_count"));
                bean.setMenuPrice(rs.getInt("menu_price"));
                bean.setUserId(rs.getString("user_id"));
                bean.setPocketTime(rs.getTimestamp("pocket_time"));
                bean.setlocalPcBean(lbean);
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(vlist.size());
        return vlist;
    }

    public Vector<MenuPocketBean> getUserPaymentAllList(String user_id){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<MenuPocketBean> vlist = new Vector<MenuPocketBean>(); //위치 중요!
        try {
            con = pool.getConnection();
            sql = "SELECT mp.menu_name, mp.menu_count, mp.menu_price, mp.user_id, mp.pocket_time ,lp.local_pcName\n" +
                    "FROM menu_pocket mp\n" +
                    "LEFT OUTER JOIN local_pc lp\n" +
                    "\tON mp.local_pcNum = lp.local_pcNum \n" +
                    "where user_id = ? order by mp.pocket_time desc";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, user_id);
            rs = pstmt.executeQuery(); //select  (쿼리와 같은 실행값)
            while(rs.next()) {//다음 레코드가 있으면 true
                //현재 커서가 있는 레코드에 값을 하나씩 가져와서 Beans에 setter 한다.
                MenuPocketBean bean = new MenuPocketBean();
                LocalPcBean lbean = new LocalPcBean();
                lbean.setLocal_pcName(rs.getString("local_pcName"));
                bean.setMenuName(rs.getString("menu_name"));
                bean.setMenuCount(rs.getInt("menu_count"));
                bean.setMenuPrice(rs.getInt("menu_price"));
                bean.setUserId(rs.getString("user_id"));
                bean.setPocketTime(rs.getTimestamp("pocket_time"));
                bean.setlocalPcBean(lbean);
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        //System.out.println(vlist.size());
        return vlist;
    }

    public Vector<MenuPocketBean> getUserPaymentDateList(String user_id){
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = null;
        Vector<MenuPocketBean> vlist = new Vector<MenuPocketBean>();
        try {
            con = pool.getConnection();
            sql = "SELECT distinct pocket_time as pocket_time FROM menu_pocket WHERE user_id = ?;";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, user_id);
            rs = pstmt.executeQuery();
            while(rs.next()) {
                MenuPocketBean bean = new MenuPocketBean();
                bean.setPocketTime(rs.getTimestamp("pocket_time"));
                vlist.addElement(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }


    public boolean insertPocket(MenuPocketBean mpbean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "INSERT INTO menu_pocket VALUES (0, ?,?,?,?,?,NOW())";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1,mpbean.getMenuName());
            pstmt.setInt(2,mpbean.getMenuCount());
            pstmt.setInt(3,mpbean.getMenuPrice());
            pstmt.setString(4, mpbean.getUserId());
            pstmt.setInt(5,mpbean.getLocalpcNum());
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    public static void main(String[] args) {
        MenuMgr mgr = new MenuMgr();
        MenuPocketBean bean = new MenuPocketBean();
        for(int i = 0; i<mgr.getUserPaymentAllList("aaa").size(); i++){
            System.out.println(mgr.getUserPaymentAllList("aaa").get(i));
        }
//        for(int i=0;i<mgr.getUserPaymentDateList("aaa").size();i++){
//            System.out.println(mgr.getUserPaymentDateList("aaa").get(i));
//        }
    }
}