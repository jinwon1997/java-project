package DB;

import bean.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class AdminMgr {
    private DBConnectionMgr pool;

    public AdminMgr() {
        pool = DBConnectionMgr.getInstance();
    }

    //피시방 정보 수정
    public boolean updatePc(LocalPcBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "UPDATE local_pc SET local_pcName = ?, local_pcAddress = ?, local_pcQuantity = ?, local_pcPhone = ? WHERE local_pcNum = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1,bean.getLocal_pcName());
            pstmt.setString(2, bean.getLocal_pcAddress());
            pstmt.setInt(3,bean.getLocal_pcQuantity());
            pstmt.setString(4,bean.getLocal_pcPhone());
            pstmt.setInt(5,bean.getLocal_pcNum());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //메뉴 정보 수정
    public boolean updateMenu(MenuBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "UPDATE pc_menu SET menu_name = ?, menu_image = ?, menu_price = ? where menu_num = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1,bean.getMenu_name());
            pstmt.setString(2, bean.getMenu_image());
            pstmt.setInt(3,bean.getMenu_price());
            pstmt.setInt(4,bean.getMenu_num());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //피시방 제거
    public void deletePc(int num) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "delete from local_pc where local_pcNum = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }
    //피시방 등록
    public boolean insertPc(LocalPcBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "INSERT local_pc values(0, ?, ?, ?, ?,?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,bean.getLocal_num());
            pstmt.setString(2,bean.getLocal_pcName());
            pstmt.setString(3, bean.getLocal_pcAddress());
            pstmt.setInt(4,bean.getLocal_pcQuantity());
            pstmt.setString(5,bean.getLocal_pcPhone());
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //메뉴 등록
    public boolean insertMenu(MenuBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "INSERT pc_menu values(0, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1,bean.getMenu_name());
            if (bean.getMenu_image().trim().length() == 0){
                pstmt.setString(2,null);
            }else {
                pstmt.setString(2,bean.getMenu_image());
            }
            pstmt.setInt(3, bean.getMenu_price());
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //메뉴제거
    public void deleteMenu(int num) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "delete from pc_menu where menu_num = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }
    public Vector<GameBean> selectChat() {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;                  // sql문의 결과가 담기는 곳
        String sql = null;
        Vector<GameBean> vlist = new Vector<GameBean>();
        try {
            con = pool.getConnection();
            sql = "select * from game";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();            // select만 가능한 코드
            while(rs.next()) {
                GameBean bean = new GameBean();
                bean.setGameNum(rs.getInt("game_num"));
                bean.setGameName(rs.getString("game_name"));
                vlist.addElement(bean);      // 벡터에 빈즈 담기
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt, rs);
        }
        return vlist;
    }

    //채팅방 제거
    public void deleteChat(int num) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        try {
            con = pool.getConnection();
            sql = "delete from game where game_num = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con, pstmt);
        }
    }

    //채팅방 등록
    public boolean insertChat(GameBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "INSERT game values(?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,bean.getGameNum());
            pstmt.setString(2,bean.getGameName());
            int cnt = pstmt.executeUpdate();      // SQL문 실행 코드
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    //채팅방 정보 수정
    public boolean updateChat(GameBean bean) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = null;
        boolean flag = false;
        try {
            con = pool.getConnection();
            sql = "UPDATE game SET game_num = ?, game_name = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1,bean.getGameNum());
            pstmt.setString(2, bean.getGameName());
            int cnt = pstmt.executeUpdate();
            if (cnt==1) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.freeConnection(con/* 실행하든 안하든 빌려온거 반납*/, pstmt);
        }
        return flag;
    }

    public static void main(String[] args) {
        AdminMgr adminMgr = new AdminMgr();
        LocalPcBean bean = new LocalPcBean();
        bean.setLocal_num(8);
        bean.setLocal_pcName("권명승 PC방");
        bean.setLocal_pcAddress("구포동에 있어요");
        bean.setLocal_pcQuantity(50);
        bean.setLocal_pcPhone("051-111-2222");
        adminMgr.insertPc(bean);
    }




}
