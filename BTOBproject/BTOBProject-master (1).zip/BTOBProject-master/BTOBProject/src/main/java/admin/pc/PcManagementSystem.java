package admin.pc;

import DB.AdminMgr;
import DB.LocalMgr;
import bean.LocalBean;
import bean.LocalPcBean;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class PcManagementSystem extends JFrame implements KeyListener {
    private JTable table;
    JPanel p;
    JLabel mainlbl;
    JButton selectbtn,createbtn, deletebtn, savebtn, backbtn;
    Choice choice;
    JTextField tf;
    LocalMgr localmgr;
    Vector<LocalBean> localvlist;
    Vector<LocalPcBean> pcBeans;
    AdminMgr adminMgr;
    RegisterPc registerPc;

    ArrayList<Integer> changedRows = new ArrayList<>();

    public PcManagementSystem() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );

        DefaultTableModel model = new DefaultTableModel(new Object[]{"번호","Check",  "피시이름", "주소", "좌석수","전화번호"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> Integer.class;
                    case 1 -> Boolean.class;
                    case 2 -> String.class;
                    case 3 -> String.class;
                    case 4 -> Integer.class;
                    case 5 -> String.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 1 || column == 2 || column == 3 || column == 4 || column == 5;
            }

        };

        p = new JPanel();
        p.setBounds(86, 653, 1041, 50);
        add(p);

        backbtn = new JButton("뒤로가기");
        backbtn.setBounds(1200,40,50,30);
        p.add(backbtn);
        backbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        table = new JTable();
        table.setModel(model);

        setBounds(100, 100, 1194, 730);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        mainlbl = new JLabel("피시방 관리 페이지");
        mainlbl.setFont(new Font("굴림", Font.PLAIN, 32));
        mainlbl.setBounds(86, 42, 364, 78);
        add(mainlbl);

        createbtn = new JButton("추가");
        createbtn.setBounds(740, 72, 97, 23);
        add(createbtn);



        deletebtn = new JButton("삭제");
        deletebtn.setBounds(883, 72, 97, 23);
        add(deletebtn);
        deletebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    boolean isSelected = (boolean) model.getValueAt(row, 1);
                    if (isSelected) {
                        int pcNum = (int) model.getValueAt(row, 0);
                        adminMgr = new AdminMgr();
                        adminMgr.deletePc(pcNum); // Make sure you have this method in AdminMgr to delete by PC number.
                    }
                }
                JOptionPane.showMessageDialog(null, "삭제 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);

                model.setNumRows(0);
                if(choice.getSelectedIndex() == 0){
                    pcBeans = localmgr.selectAllPc("*");
                    for (int i = 0; i <= pcBeans.size()-1; i++) {
                        LocalPcBean pcbean = pcBeans.get(i);
                        model.addRow(new Object[]{pcbean.getLocal_pcNum(),false, pcbean.getLocal_pcName(), pcbean.getLocal_pcAddress()
                                ,pcbean.getLocal_pcQuantity(), pcbean.getLocal_pcPhone()});
                    }
                }else{
                    if (tf.getText().trim().length() > 0) {
                        pcBeans = localmgr.selectFindPc(choice.getSelectedIndex(), tf.getText());
                        for (int i = 0; i < pcBeans.size(); i++) {
                            LocalPcBean localpcbean = pcBeans.get(i);
                            model.addRow(new Object[]{localpcbean.getLocal_pcNum(),false, localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                    ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                        }
                    } else if (tf.getText().trim().length() == 0) {
                        pcBeans = localmgr.selectLocalPcList(choice.getSelectedIndex(),"*");
                        for (int i = 0; i < pcBeans.size(); i++) {
                            LocalPcBean localpcbean = pcBeans.get(i);
                            if(localpcbean.getLocal_pcName() != null) {
                                model.addRow(new Object[]{localpcbean.getLocal_pcNum(),false, localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                        ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                            }
                        }
                    }
                    localmgr.selectFindPc(choice.getSelectedIndex()+1,tf.getText().trim());
                }
                changedRows.clear(); // 리스트를 비웁니다.
            }
        });

        savebtn = new JButton("저장");
        savebtn.setBounds(1030, 72, 97, 23);
        add(savebtn);

        createbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RegisterPc();
                dispose();
            }
        });
        savebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    LocalPcBean bean = new LocalPcBean();
                    bean.setLocal_pcNum((int) model.getValueAt(row, 0));
                    bean.setLocal_pcName((String) model.getValueAt(row, 2));
                    bean.setLocal_pcAddress((String) model.getValueAt(row, 3));
                    bean.setLocal_pcQuantity((int) model.getValueAt(row, 4));
                    bean.setLocal_pcPhone((String) model.getValueAt(row, 5));
                    adminMgr = new AdminMgr();
                    adminMgr.updatePc(bean);

                }
                JOptionPane.showMessageDialog(null, "수정 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
                changedRows.clear(); // 리스트를 비웁니다.
            }
        });


        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                if (!changedRows.contains(row)) {
                    changedRows.add(row);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(86, 192, 1041, 460);
        localmgr = new LocalMgr();
        localvlist = localmgr.getLocalname();

        //지역 초이스 삽입
        choice = new Choice();
        choice.add("전체조회");
        localmgr.selectAllPc("*");
        Map<String, Integer> map = new HashMap<String, Integer>();
        for (int i = 0; i < localvlist.size(); i++) {
            LocalBean bean = localvlist.get(i);
            String str1 = bean.getLocalName().trim();
            map.put(str1, i + 1);
            choice.add(str1);
        }
        choice.setBounds(690, 165, 143, 21);
        add(choice);

        tf = new JTextField();
        tf.setBounds(866, 165, 140, 21);
        add(tf);



        selectbtn = new JButton("검색하기");
        selectbtn.setBounds(1030, 163, 97, 23);
        add(selectbtn);
        selectbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setNumRows(0);
                if(choice.getSelectedIndex() == 0){
                    if (tf.getText().trim().length() > 0) {
                        pcBeans = localmgr.selectAllPc(tf.getText().trim());
                        for (int i = 0; i < pcBeans.size(); i++) {
                            LocalPcBean localpcbean = pcBeans.get(i);
                            model.addRow(new Object[]{localpcbean.getLocal_pcNum(),false, localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                    ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                        }
                    } else if (tf.getText().trim().length() == 0) {
                        pcBeans = localmgr.selectAllPc("*");
                        for (int i = 0; i <= pcBeans.size()-1; i++) {
                            LocalPcBean pcbean = pcBeans.get(i);
                            model.addRow(new Object[]{pcbean.getLocal_pcNum(),false, pcbean.getLocal_pcName(), pcbean.getLocal_pcAddress()
                                    ,pcbean.getLocal_pcQuantity(), pcbean.getLocal_pcPhone()});
                        }
                    }

                }else{
                    if (tf.getText().trim().length() > 0) {
                        pcBeans = localmgr.selectFindPc(choice.getSelectedIndex(), tf.getText());
                        for (int i = 0; i < pcBeans.size(); i++) {
                            LocalPcBean localpcbean = pcBeans.get(i);
                            model.addRow(new Object[]{localpcbean.getLocal_pcNum(),false, localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                    ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                        }
                    } else if (tf.getText().trim().length() == 0) {
                        pcBeans = localmgr.selectLocalPcList(choice.getSelectedIndex(),"*");
                        for (int i = 0; i < pcBeans.size(); i++) {
                            LocalPcBean localpcbean = pcBeans.get(i);
                            if(localpcbean.getLocal_pcName() != null) {
                                model.addRow(new Object[]{localpcbean.getLocal_pcNum(),false, localpcbean.getLocal_pcName(), localpcbean.getLocal_pcAddress()
                                        ,localpcbean.getLocal_pcQuantity(), localpcbean.getLocal_pcPhone()});
                            }
                        }
                    }
                    localmgr.selectFindPc(choice.getSelectedIndex()+1,tf.getText().trim());
                }
            }
        });

        pcBeans = new Vector<>();
        pcBeans = localmgr.selectAllPc("*");

        //처음 로드 데이터 삽입
        for (int i = 0; i <= pcBeans.size()-1; i++) {
            LocalPcBean pcbean = pcBeans.get(i);
            model.addRow(new Object[]{pcbean.getLocal_pcNum(),false, pcbean.getLocal_pcName(), pcbean.getLocal_pcAddress(),pcbean.getLocal_pcQuantity(), pcbean.getLocal_pcPhone()});
        }
        //다음 선택 검색 할때 해줘야함

        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setMaxWidth(50);

        table.getTableHeader().setReorderingAllowed(false);         // 컬럼들 이동 불가
        table.getTableHeader().setResizingAllowed(false);           // 컬럼 크기 조절 불가

        table.setDefaultRenderer(String.class, centerRenderer);
        table.setDefaultRenderer(Integer.class, centerRenderer);

        add(scrollPane);
        setResizable(false);
        setVisible(true);
        validate();

        choice.addKeyListener(this);
        tf.addKeyListener(this);
    }



    public static void main(String[] args) {
        new PcManagementSystem();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            selectbtn.doClick();  // 로그인 버튼 클릭 시뮬레이트
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}