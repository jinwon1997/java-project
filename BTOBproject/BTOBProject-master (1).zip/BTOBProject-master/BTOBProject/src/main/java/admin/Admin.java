package admin;


import DB.AdminMgr;
import admin.chat.ChatManageMentSystem;
import admin.menu.MenuManageMentSystem;
import admin.pc.PcManagementSystem;
import bean.GameBean;
import form.ChatServer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Admin extends JFrame{

    JButton pcadmin, menuadmin, chatadmin;
    AdminMgr adminMgr;
    Vector<GameBean> gameBeans;

    public Admin() {

        setTitle("관리자");
        setBounds(100, 100, 320, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);


        //관리자가 로그인시 채팅방 서버 포트를 열음.
        adminMgr = new AdminMgr();
        gameBeans = adminMgr.selectChat();

        ExecutorService threadPool = Executors.newFixedThreadPool(adminMgr.selectChat().size());
        for(int i=0;i<adminMgr.selectChat().size();i++){
            int finalI = i;
            threadPool.submit(() -> new ChatServer(gameBeans.get(finalI).getGameNum()));
        }

        pcadmin = new JButton("pcadmin");
        pcadmin.setForeground(new Color(255, 255, 255));
        pcadmin.setBackground(new Color(0, 0, 0));
        pcadmin.setBounds(63, 0, 180, 120);
        add(pcadmin);
        pcadmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PcManagementSystem pcManagementSystem = new PcManagementSystem();
            }
        });

        menuadmin = new JButton("menuadmin");
        menuadmin.setForeground(new Color(255, 255, 255));
        menuadmin.setBackground(new Color(0, 0, 0));
        menuadmin.setBounds(63, 120, 180, 120);
        add(menuadmin);
        menuadmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MenuManageMentSystem menuManageMentSystem = new MenuManageMentSystem();
            }
        });

        chatadmin = new JButton("chatadmin");
        chatadmin.setForeground(new Color(255, 255, 255));
        chatadmin.setBackground(new Color(0, 0, 0));
        chatadmin.setBounds(63, 231, 180, 120);
        add(chatadmin);
        chatadmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ChatManageMentSystem chatManageMentSystem = new ChatManageMentSystem();
            }
        });

        setVisible(true);
        setResizable(false);
        validate();
    }

    public static void main(String[] args) {
        new Admin();
    }
}
