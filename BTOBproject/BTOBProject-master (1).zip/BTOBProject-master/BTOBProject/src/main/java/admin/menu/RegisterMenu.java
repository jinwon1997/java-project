package admin.menu;


import DB.AdminMgr;
import DB.LocalMgr;
import bean.MenuBean;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class RegisterMenu extends JFrame implements ActionListener, ItemListener {

    JButton btn2, btn3;
    JTextField tf1,tf2, tf3, tf4;
    JComboBox<String> ch;
    LocalMgr mgr;
    AdminMgr adminMgr;
    MenuManageMentSystem menuManageMentSystem;

    public RegisterMenu() {
        setSize(500, 500);
        setTitle("피시방 추가");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 패널 생성
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(255, 255, 255));

        GridBagConstraints c = new GridBagConstraints();

        mgr = new LocalMgr();

        tf1 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(tf1, c);

        tf2 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(tf2, c);

        tf3 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 2;
        panel.add(tf3, c);


        btn2 = new JButton("등록");
        c.gridx = 0;
        c.gridy = 5;
        panel.add(btn2, c);

        btn3 = new JButton("취소");
        c.gridx = 1;
        c.gridy = 5;
        panel.add(btn3, c);

        JLabel itf1 = new JLabel("메뉴 명");
        c.gridx = 0;
        c.gridy = 0;
        panel.add(itf1, c);

        JLabel itf5 = new JLabel("메뉴 이미지");
        c.gridx = 0;
        c.gridy = 1;
        panel.add(itf5, c);

        JLabel itf5_2 = new JLabel("메뉴 가격");
        c.gridx = 0;
        c.gridy = 2;
        panel.add(itf5_2, c);

        // 프레임에 패널 추가
        add(panel);

        btn2.addActionListener(this);
        btn3.addActionListener(this);

        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj == btn2){
            MenuBean menuBean = new MenuBean();
            menuBean.setMenu_name(tf1.getText().trim());
            menuBean.setMenu_image(tf2.getText().trim());
            menuBean.setMenu_price(Integer.parseInt(tf3.getText().trim()));
            adminMgr = new AdminMgr();
            adminMgr.insertMenu(menuBean);
            JOptionPane.showMessageDialog(null, "등록 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
            menuManageMentSystem = new MenuManageMentSystem();
            dispose();
        }else if(obj == btn3){
            menuManageMentSystem = new MenuManageMentSystem();
            dispose();
        }
    }

    public static void main(String[] args) {
        new RegisterMenu();
    }
}
