package admin.chat;

import DB.*;
import admin.pc.RegisterPc;
import bean.GameBean;
import bean.LocalBean;
import bean.LocalPcBean;
import bean.MenuBean;
import form.Game;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

public class ChatManageMentSystem extends JFrame {
    private JTable table;
    JPanel p;
    JLabel mainlbl;
    JButton createbtn, deletebtn, savebtn,backbtn;
    Vector<GameBean> gamevlist;
    ChatMgr chatMgr;
    AdminMgr adminMgr;

    ArrayList<Integer> changedRows = new ArrayList<>();

    public ChatManageMentSystem() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );

        DefaultTableModel model = new DefaultTableModel(new Object[]{"포트번호","Check",  "게임 이름"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> Integer.class;
                    case 1 -> Boolean.class;
                    case 2 -> Integer.class;
                    case 3 -> String.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
        };
        p = new JPanel();
        p.setBounds(86, 653, 1041, 50);
        add(p);

        backbtn = new JButton("뒤로가기");
        backbtn.setBounds(1200,40,50,30);
        p.add(backbtn);
        backbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        table = new JTable();
        table.setModel(model);

        setBounds(100, 100, 1194, 730);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        mainlbl = new JLabel("메뉴 관리 페이지");
        mainlbl.setFont(new Font("굴림", Font.PLAIN, 32));
        mainlbl.setBounds(86, 42, 364, 78);
        add(mainlbl);

        createbtn = new JButton("추가");
        createbtn.setBounds(740, 72, 97, 23);
        add(createbtn);
        createbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RegisterChat();
                dispose();
            }
        });

        deletebtn = new JButton("삭제");
        deletebtn.setBounds(883, 72, 97, 23);
        add(deletebtn);

        deletebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    boolean isSelected = (boolean) model.getValueAt(row, 1);
                    if (isSelected) {
                        int gameNum = (int) model.getValueAt(row, 0);
                        adminMgr = new AdminMgr();
                        adminMgr.deleteChat(gameNum);
                    }
                }
                JOptionPane.showMessageDialog(null, "삭제 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);

                model.setNumRows(0);
                gamevlist = chatMgr.getChatList();
                for (int i = 0; i <= gamevlist.size()-1; i++) {
                    GameBean gameBean = gamevlist.get(i);
                    model.addRow(new Object[]{gameBean.getGameNum(),false, gameBean.getGameName()});
                }
            }
        });

        savebtn = new JButton("저장");
        savebtn.setBounds(1030, 72, 97, 23);
        add(savebtn);

        savebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    GameBean bean = new GameBean();
                    bean.setGameNum((int) model.getValueAt(row, 0));
                    bean.setGameName((String) model.getValueAt(row, 2));
                    adminMgr = new AdminMgr();
                    adminMgr.updateChat(bean);
                }
                JOptionPane.showMessageDialog(null, "수정 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
                changedRows.clear(); // 리스트를 비웁니다.
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(86, 192, 1041, 460);

        chatMgr = new ChatMgr();
        gamevlist = chatMgr.getChatList();

        table.setRowHeight(100);
        //처음 로드 데이터 삽입
        for (int i = 0; i <= gamevlist.size()-1; i++) {
            GameBean gameBean = gamevlist.get(i);
            model.addRow(new Object[]{gameBean.getGameNum(),false, gameBean.getGameName()});
        }

        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                if (!changedRows.contains(row)) {
                    changedRows.add(row);
                }
            }
        });
        // 이미지를 렌더링하기 위한 셀 렌더러 클래스


        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setMaxWidth(50);
        table.getTableHeader().setReorderingAllowed(false);         // 컬럼들 이동 불가
        table.getTableHeader().setResizingAllowed(false);           // 컬럼 크기 조절 불가

        table.setDefaultRenderer(String.class, centerRenderer);
        table.setDefaultRenderer(Integer.class, centerRenderer);

        add(scrollPane);
        setResizable(false);
        setVisible(true);
        validate();
    }


    public static void main(String[] args) {
        new ChatManageMentSystem();
    }
}