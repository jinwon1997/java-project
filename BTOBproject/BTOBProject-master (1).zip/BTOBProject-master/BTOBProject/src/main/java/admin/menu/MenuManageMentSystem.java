package admin.menu;

import DB.AdminMgr;
import DB.LocalMgr;
import DB.MenuMgr;
import admin.pc.RegisterPc;
import bean.LocalBean;
import bean.LocalPcBean;
import bean.MenuBean;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Vector;

public class MenuManageMentSystem extends JFrame {
    private JTable table;
    JPanel p;
    JLabel mainlbl;
    JButton createbtn, deletebtn, savebtn,backbtn;
    Vector<MenuBean> menuvlist;
    MenuMgr menumgr;
    AdminMgr adminMgr;

    ArrayList<Integer> changedRows = new ArrayList<>();

    public MenuManageMentSystem() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );

        DefaultTableModel model = new DefaultTableModel(new Object[]{"번호","Check",  "메뉴명", "메뉴 이미지","메뉴 URL", "메뉴 가격"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> Integer.class;
                    case 1 -> Boolean.class;
                    case 2 -> String.class;
                    case 3 -> Icon.class;
                    case 4 -> String.class;
                    case 5 -> Integer.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0 || column != 3 ;
            }
        };
        p = new JPanel();
        p.setBounds(86, 653, 1041, 50);
        add(p);
        backbtn = new JButton("뒤로가기");
        backbtn.setBounds(1200,40,50,30);
        p.add(backbtn);
        backbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        table = new JTable();
        table.setModel(model);

        setBounds(100, 100, 1194, 730);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        mainlbl = new JLabel("메뉴 관리 페이지");
        mainlbl.setFont(new Font("굴림", Font.PLAIN, 32));
        mainlbl.setBounds(86, 42, 364, 78);
        add(mainlbl);

        createbtn = new JButton("추가");
        createbtn.setBounds(740, 72, 97, 23);
        add(createbtn);
        createbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RegisterMenu();
                dispose();
            }
        });

        deletebtn = new JButton("삭제");
        deletebtn.setBounds(883, 72, 97, 23);
        add(deletebtn);

        deletebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    boolean isSelected = (boolean) model.getValueAt(row, 1);
                    if (isSelected) {
                        int menuNum = (int) model.getValueAt(row, 0);
                        adminMgr = new AdminMgr();
                        adminMgr.deleteMenu(menuNum);
                    }
                }
                JOptionPane.showMessageDialog(null, "삭제 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);

                model.setNumRows(0);
                menuvlist = menumgr.getMenuList();

                for (int i = 0; i <= menuvlist.size()-1; i++) {
                    MenuBean menubean = menuvlist.get(i);
                    if (menubean.getMenu_image() ==  null ){
                        try {
                            URL url = new URL("https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2F20160402_19%2Fmaddara_1459606960178nrrdB_JPEG%2FUntitled-1.jpg&type=sc960_832");
                            ImageIcon icon = new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
                            model.addRow(new Object[]{menubean.getMenu_num(), false, menubean.getMenu_name(), icon, menubean.getMenu_image(), menubean.getMenu_price()});
                        } catch (MalformedURLException c) {
                            c.printStackTrace();
                        }
                    }else {
                        try {
                            URL url = new URL(menubean.getMenu_image());
                            ImageIcon icon = new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
                            model.addRow(new Object[]{menubean.getMenu_num(), false, menubean.getMenu_name(), icon, menubean.getMenu_image(), menubean.getMenu_price()});
                        } catch (MalformedURLException c) {
                            c.printStackTrace();
                        }
                    }
                }
            }
        });

        savebtn = new JButton("저장");
        savebtn.setBounds(1030, 72, 97, 23);
        add(savebtn);

        savebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int row : changedRows) {
                    MenuBean bean = new MenuBean();
                    bean.setMenu_num((int) model.getValueAt(row, 0));
                    bean.setMenu_name((String) model.getValueAt(row, 2));
                    bean.setMenu_image((String) model.getValueAt(row, 4));
                    bean.setMenu_price((int) model.getValueAt(row, 5));
                    adminMgr = new AdminMgr();
                    adminMgr.updateMenu(bean);

                }
                JOptionPane.showMessageDialog(null, "수정 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
                changedRows.clear(); // 리스트를 비웁니다.
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(86, 192, 1041, 460);

        menumgr = new MenuMgr();
        menuvlist = menumgr.getMenuList();

        table.setRowHeight(100);
        //처음 로드 데이터 삽입
        for (int i = 0; i <= menuvlist.size()-1; i++) {
            MenuBean menubean = menuvlist.get(i);
            if(menubean.getMenu_image() != null){
                if (menubean.getMenu_image().substring(0,4) != "http:" || menubean.getMenu_image().substring(0,5) != "https:"){
                    try {
                        URL url = new URL(menubean.getMenu_image());
                        ImageIcon icon = new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
                        model.addRow(new Object[]{menubean.getMenu_num(), false, menubean.getMenu_name(), icon, menubean.getMenu_image(), menubean.getMenu_price()});
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                }
            }else{
                try {
                    URL url = new URL("https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2F20160402_19%2Fmaddara_1459606960178nrrdB_JPEG%2FUntitled-1.jpg&type=sc960_832");
                    ImageIcon icon = new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
                    model.addRow(new Object[]{menubean.getMenu_num(), false, menubean.getMenu_name(), icon, menubean.getMenu_image(), menubean.getMenu_price()});
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
        }
        // 셀 렌더러 설정
        table.getColumnModel().getColumn(3).setCellRenderer(new ImageRenderer());


        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                if (!changedRows.contains(row)) {
                    changedRows.add(row);
                }
            }
        });
        // 이미지를 렌더링하기 위한 셀 렌더러 클래스


        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setMaxWidth(50);
        table.getTableHeader().setReorderingAllowed(false);         // 컬럼들 이동 불가
        table.getTableHeader().setResizingAllowed(false);           // 컬럼 크기 조절 불가

        table.setDefaultRenderer(String.class, centerRenderer);
        table.setDefaultRenderer(Integer.class, centerRenderer);

        add(scrollPane);
        setResizable(false);
        setVisible(true);
        validate();
    }


    class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel label = new JLabel();
            if (value != null) {
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setIcon((Icon) value);
            }
            return label;
        }
    }
    public static void main(String[] args) {
        new MenuManageMentSystem();
    }
}