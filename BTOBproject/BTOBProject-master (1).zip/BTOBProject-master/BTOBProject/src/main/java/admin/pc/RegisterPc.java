package admin.pc;


import DB.AdminMgr;
import DB.MemberMgr;
import bean.LocalBean;
import DB.LocalMgr;
import bean.LocalPcBean;
import bean.MemberBean;
import form.DialogBox;
import form.LoginHome;
import security.Encryption;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.swing.*;


import javax.swing.*;
import java.awt.*;

public class RegisterPc extends JFrame implements ActionListener, ItemListener {

    JButton btn2, btn3;
    JTextField tf1,tf2, tf3, tf4;
    JComboBox<String> ch;
    LocalMgr mgr;
    AdminMgr adminMgr;
    PcManagementSystem pcManagementSystem;

    public RegisterPc() {
        setSize(500, 500);
        setTitle("피시방 추가");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 패널 생성
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(255, 255, 255));

        GridBagConstraints c = new GridBagConstraints();

        mgr = new LocalMgr();

        tf1 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(tf1, c);

        Vector<LocalBean> vlist = mgr.getLocalname();
        String str[] = new String[16];
        for (int i = 0; i < str.length; i++) {
            LocalBean bean = vlist.get(i);
            str[i] = bean.getLocalName().trim();
        }
        ch = new JComboBox<String>(str);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(ch, c);

        tf2 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 2;
        panel.add(tf2, c);

        tf3 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 3;
        panel.add(tf3, c);

        tf4 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 4;
        panel.add(tf4, c);


        btn2 = new JButton("등록");
        c.gridx = 0;
        c.gridy = 5;
        panel.add(btn2, c);

        btn3 = new JButton("취소");
        c.gridx = 1;
        c.gridy = 5;
        panel.add(btn3, c);

        JLabel itf1 = new JLabel("피시방 이름");
        c.gridx = 0;
        c.gridy = 0;
        panel.add(itf1, c);

        JLabel itf5 = new JLabel("지역 주소");
        c.gridx = 0;
        c.gridy = 1;
        panel.add(itf5, c);

        JLabel itf5_2 = new JLabel("상세 주소");
        c.gridx = 0;
        c.gridy = 2;
        panel.add(itf5_2, c);

        JLabel itf6 = new JLabel("전화번호");
        c.gridx = 0;
        c.gridy = 3;
        panel.add(itf6, c);

        JLabel itf8 = new JLabel("좌석수");
        c.gridx = 0;
        c.gridy = 4;
        panel.add(itf8, c);

        // 프레임에 패널 추가
        add(panel);

        btn2.addActionListener(this);
        btn3.addActionListener(this);

        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj == btn2){
            LocalPcBean localPcBean = new LocalPcBean();
            localPcBean.setLocal_pcName(tf1.getText().trim());
            localPcBean.setLocal_num(ch.getSelectedIndex()+1);
            localPcBean.setLocal_pcAddress(tf2.getText().trim());
            localPcBean.setLocal_pcPhone(tf3.getText().trim());
            localPcBean.setLocal_pcQuantity(Integer.parseInt(tf4.getText().trim()));
            adminMgr = new AdminMgr();
            adminMgr.insertPc(localPcBean);
            JOptionPane.showMessageDialog(null, "등록 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
            pcManagementSystem = new PcManagementSystem();
            dispose();
        }else if(obj == btn3){
            pcManagementSystem = new PcManagementSystem();
            dispose();
        }
    }

    public static void main(String[] args) {
        new RegisterPc();
    }
}
