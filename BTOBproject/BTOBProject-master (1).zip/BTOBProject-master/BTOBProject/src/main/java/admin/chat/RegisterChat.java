package admin.chat;


import DB.AdminMgr;
import DB.ChatMgr;
import DB.LocalMgr;
import bean.GameBean;
import bean.MenuBean;
import form.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

public class RegisterChat extends JFrame implements ActionListener {

    JButton btn2, btn3;
    JTextField tf1,tf2;
    AdminMgr adminMgr;
    Vector<GameBean>Gamebeans;
    ChatManageMentSystem chatManageMentSystem;

    public RegisterChat() {
        setSize(500, 500);
        setTitle("채팅방 추가");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 패널 생성
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(255, 255, 255));

        GridBagConstraints c = new GridBagConstraints();

        tf1 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(tf1, c);

        tf2 = new JTextField(15);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(tf2, c);


        btn2 = new JButton("등록");
        c.gridx = 0;
        c.gridy = 5;
        panel.add(btn2, c);

        btn3 = new JButton("취소");
        c.gridx = 1;
        c.gridy = 5;
        panel.add(btn3, c);

        JLabel itf1 = new JLabel("채팅방 포트번호");
        c.gridx = 0;
        c.gridy = 0;
        panel.add(itf1, c);

        JLabel itf5 = new JLabel("채팅방 이름");
        c.gridx = 0;
        c.gridy = 1;
        panel.add(itf5, c);

        // 프레임에 패널 추가
        add(panel);

        btn2.addActionListener(this);
        btn3.addActionListener(this);

        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj == btn2){
            Gamebeans = new Vector();
            ChatMgr mgr = new ChatMgr();
            Gamebeans = mgr.getChatList();
            for (int i = 0; i < Gamebeans.size(); i++) {
                GameBean gameBean = Gamebeans.get(i);
                if(Integer.parseInt(tf1.getText().trim())==(gameBean.getGameNum())) {
                    JOptionPane.showMessageDialog(null, "이미 존재하는 포트번호 입니다.", "알림", JOptionPane.WARNING_MESSAGE);
                    tf1.setText("");
                    tf1.requestFocus();
                    break;
                }
            }
            if(tf2.getText().trim().length()==0) {
                JOptionPane.showMessageDialog(null, "채팅방 이름을 입력해주세요.", "알림", JOptionPane.WARNING_MESSAGE);
                tf2.setText("");
                tf2.requestFocus();
            }
            GameBean gameBean = new GameBean();
            gameBean.setGameNum(Integer.parseInt(tf1.getText().trim()));
            gameBean.setGameName(tf2.getText().trim());
            adminMgr = new AdminMgr();
            adminMgr.insertChat(gameBean);
            JOptionPane.showMessageDialog(null, "등록 되었습니다.", "알림", JOptionPane.WARNING_MESSAGE);
            chatManageMentSystem = new ChatManageMentSystem();
            dispose();
        }else if(obj == btn3){
            chatManageMentSystem = new ChatManageMentSystem();
            dispose();
        }
    }

    public static void main(String[] args) {
        new RegisterChat();
    }
}