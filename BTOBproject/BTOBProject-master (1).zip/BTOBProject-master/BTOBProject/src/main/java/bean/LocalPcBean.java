package bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class LocalPcBean {

    private int local_pcNum;
    private int local_num;
    private String local_pcName;
    private String local_pcAddress;
    private int local_pcQuantity;
    private String local_pcPhone;

}
