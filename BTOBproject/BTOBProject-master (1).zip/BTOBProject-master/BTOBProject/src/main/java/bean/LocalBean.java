package bean;


// 테이블명 + Bean

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class LocalBean {

    private int localNum;
    private String localName;

}
