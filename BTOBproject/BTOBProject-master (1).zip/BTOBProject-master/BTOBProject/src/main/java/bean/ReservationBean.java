package bean;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationBean {

    public void setStart_Time(Timestamp start_Time) {
        this.start_Time = start_Time;
    }
    public void setEnd_Time(Timestamp end_Time) {
        this.end_Time = end_Time;
    }

    private int Reservation_Num;
    private int Seat_Num;
    private String userId;
    private Timestamp connecting_Time;
    private Timestamp reservation_Time;
    private Timestamp start_Time;
    private Timestamp end_Time;
}
