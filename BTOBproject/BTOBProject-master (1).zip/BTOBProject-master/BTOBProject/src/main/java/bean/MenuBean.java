package bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuBean {
    private int menu_num;
    private  int menu_price;
    private String menu_image;
    private int menu_quantity;
    private  String menu_name;
}
