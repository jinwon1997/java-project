package bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class PcSeatBean {
    private int seat_Num;
    private String userId;
    private int local_pcNum;
    private int pc_Statement;

    private ReservationBean reservation; // ReservationBean 객체 추가

    // ... (다른 변수에 대한 getter와 setter 메서드)

    public ReservationBean getReservation() {
        return reservation;
    }

    public void setReservation(ReservationBean reservation) {
        this.reservation = reservation;
    }

}
