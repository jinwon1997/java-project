package bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

// 테이블명 + Bean
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberBean {

    private int num;

    private String userId;
    private String userPassword;
    private String name;
    private String address;
    private String phone;
    private int gender;
    private String registerDate;
    private String ustime;
    private String socialNum;
    private int user_mst;
    private int seat_number;
    private int localNum;
    private int userCharge;
    private int userState;
    private int userAuthority;

}
