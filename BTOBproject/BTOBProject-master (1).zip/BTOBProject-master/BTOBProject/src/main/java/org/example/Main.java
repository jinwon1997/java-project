package org.example;

import form.LoginHome;

public class Main {
    public static void main(String[] args) {
        LoginHome loginHome = new LoginHome();
    }
}